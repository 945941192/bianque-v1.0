#!/bin/bash
#########################################################################
# File Name: up.sh
# Author: PeiYuan
# Mail: peiyuan.wc@alibaba-inc.com
# Description:
# Created Time: Thu Sep  7 09:56:22 2017
#########################################################################

set -x
git pull
git merge master -m "merge master"
git push
