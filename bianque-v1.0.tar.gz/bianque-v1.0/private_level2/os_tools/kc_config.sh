#!/bin/bash
######################################################################
# File Name: kdump_conman_check.sh
# Version: V1.1
# Author: Liushiyi
# Employee Number: WB303203
# Mail: wb-lsy303203@alibaba-inc.com
# Description: setup and check kdump and conman service
# Created Time: Fri Sep 15 11:22:06 CST 2017
######################################################################

#set -o pipefail
reboot=""
setup_conman=0
setup_kdump=0
show_info=0
tty=""
bot=""
el5=$(cat /etc/redhat-release|grep " 5\."|wc -l)
el6=$(cat /etc/redhat-release|grep " 6\."|wc -l)
el7=$(cat /etc/redhat-release|grep " 7\."|wc -l)
NO_FILE_EXIST=3

result()
{
    local res=$1
    local cmd_info=$2
    case $res in
        1)printf "%-60s" "$cmd_info"
        printf "\t\E[1;31;32mPASS\E[0m\n";;
        2)printf "%-60s" "$cmd_info"
        printf "\t\E[1;31;31mFAIL\E[0m\n";;
    esac
}

conman_grub_check()
{
    [ $el7 -eq 1 ] && local file_name="/etc/grub2.cfg" || local file_name="/etc/grub.conf"
    local flag=$(grep -c "ttyS" $file_name)
    [[ $flag -ge 1 ]] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_securetty_check()
{
    local file_name="/etc/securetty"
    local flag=$(grep -Ec "ttyS0|ttyS1" $file_name)
    [ $flag -eq 1 ] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_inittab_check()
{
    local file_name="/etc/inittab"
    local flag=$(grep -c "ttyS" $file_name)
    [ $flag -ge 1 ] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_printk_check()
{
    local file_name="/proc/sys/kernel/printk"
    [ "$(cat $file_name)" == "5	4	1	5" ] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_sysctl_check()
{
    local file_name="/etc/sysctl.conf"
    local flag=$(grep -c "kernel.printk = 5 4 1 5" $file_name)
    [ $flag -eq 1 ] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_agetty_check()
{
    local flag=$(ps -ef|grep -i agetty|grep -v grep|awk '{print $6}'|grep -Ec 'ttyS0|ttyS1')
    [ $flag -eq 1 ] && result 1 "The agetty check is right!" || result 2 "The agetty check is wrong!"
}

conman_cmdline_check()
{
    local file_name="/proc/cmdline"
    local flag=$(grep -c "ttyS" $file_name)
    [[ $flag -ge 1 ]] && result 1 "$file_name check is right!" || result 2 "$file_name check is wrong!"
}

conman_check()
{
    if [[ "$reboot" == "before" ]] && [ $setup_conman -eq 1 ];then
        echo -e ">>>>>>>>>>>>Check the conman before reboot<<<<<<<<<<<"
        conman_grub_check
        conman_securetty_check
        conman_printk_check
        conman_sysctl_check
        [ $el5 -eq 1 ] && conman_inittab_check
    elif [[ "$reboot" == "after" ]] && [ $setup_conman -eq 1 ];then
        echo -e ">>>>>>>>>>>>Check the conman after reboot<<<<<<<<<<<"
        conman_cmdline_check
        conman_securetty_check
        conman_printk_check
        conman_sysctl_check
        conman_agetty_check
    else
        return
    fi
}
conman_setup()
{
    [ $setup_conman -eq 0 ] || [ "$reboot" != "before" ] && return
    echo -e ">>>>>>>>>>>>Config the conman before reboot<<<<<<<<<<<"
    if [ "$tty" == "" ];then
        local tty_num=$(cat /proc/tty/driver/serial | egrep -v 'unknow|serinfo' |head -n 1| awk '{print $1}' | sed 's/://g')
        tty="ttyS${tty_num}"
    fi
    [ "$bot" == "" ] && bot=$(setserial -a "/dev/$tty" | grep Baud_base | awk '{print $2}' | sed 's/,//g')

    if ! echo $tty |grep -q ttyS;then
        usage
        exit 1
    fi

    if ! echo $bot"X" |grep -qE "^9600X|^115200X|^38400X|^19200X|^57600X";then
        usage
        exit 1
    fi
    grubby --args="console=tty0 console=$tty,$bot" --update-kernel=ALL
    sed -i "/ttyS/d" /etc/securetty
    echo $tty >> /etc/securetty

    if [ $el5 -eq 1 ];then
        sed -i "/agetty ttyS/d" /etc/inittab
        echo "S0:2345:respawn:/sbin/agetty $tty $bot vt100-nav" >> /etc/inittab
    fi
    sed -i "/kernel.printk/d" /etc/sysctl.conf
    echo "5 4 1 5" >  /proc/sys/kernel/printk
    echo "kernel.printk = 5 4 1 5" >> /etc/sysctl.conf
}
kdump_show_info()
{
    echo ">>>>>>>>>>>>>>>>>> info about kdump <<<<<<<<<<<<<<<<<<<"
    local kexec_rpm="$(rpm -qa|grep 'kexec-tools')"
    [[ "$kexec_rpm" == "" ]] && echo "Have not install kexec-tools rpm" || echo "Current kexec-tools is $kexec_rpm"
    if [ $el5 -eq 1 ];then
        [[ "$kexec_rpm" != "kexec-tools-1.102pre-165.alios5" ]] && echo "Please update your kexec-tools to kexec-tools-1.102pre-165.alios5" && show_info=1
    fi
    [ -e /etc/kdump.conf ] && echo "The content of /etc/kdump.conf is" && grep -v "#" /etc/kdump.conf
}
kdump_setup()
{
    [[ "$reboot" == "before" ]] && kdump_show_info
    [ $show_info -eq 1 ] && return   
    [[ "$reboot" == "after" ]] && return
    echo -e ">>>>>>>>>>>>Config the kdump before reboot<<<<<<<<<<<"
    local device=$(df -lh /var |tail -1 |awk '{print $1}')
    local filesystem=$(mount|grep -w $device|awk '{print $(NF-1)}')
    local datetime=$(date +%Y%m%d%H%M%S)

    echo "Start to config kdump.conf ..."
    [ -e /etc/kdump.conf ] && cp /etc/kdump.conf /etc/kdump.conf.${datetime} && echo "Backup /etc/kdump.conf to /etc/kdump.conf.${datetime}"
    > /etc/kdump.conf
    echo "$filesystem $device" >> /etc/kdump.conf
    echo "path /var/crash" >> /etc/kdump.conf
    echo "core_collector makedumpfile -c --message-level 1 -d 31" >> /etc/kdump.conf
    echo "extra_modules mpt2sas mpt3sas megaraid_sas hpsa ahci" >> /etc/kdump.conf
    echo "default reboot" >> /etc/kdump.conf

    if [ $el7 -eq 1 ];then
        systemctl enable kdump
    else
        sed -i "s/mkdumprd -d/mkdumprd --allow-missing -d/" /etc/init.d/kdump
        chkconfig --level 2345 kdump on
    fi

    echo "Start to config booting parameter ..."
    if [ $el7 -eq 1 ];then
        grubby --args='crashkernel=auto' --update-kernel=ALL
    elif [ $el6 -eq 1 ];then
        grubby --args='crashkernel=256M' --update-kernel=ALL
    else
        grubby --args='crashkernel=256M@64M' --update-kernel=ALL
    fi
}
kdump_grub_check()
{
    if [ $el7 -eq 1 ];then
        local file_name="/etc/grub2.cfg"
        local flag=$(grep "crashkernel=auto" $file_name|head -1|wc -l)
    elif [ $el6 -eq 1 ];then
        local file_name="/etc/grub.conf"
        local flag=$(grep "crashkernel=256M" $file_name|head -1|wc -l)
    else
        local file_name="/etc/grub.conf"
        local flag=$(grep "crashkernel=256M@64M" $file_name|head -1|wc -l)
    fi
    
    [ $flag -eq 1 ] && result 1 "The value of crashkernel in $file_name is right!" || result 2 "The value of crashkernel in $file_name is wrong!"
}

kdump_cmdline_check()
{
    local file_name="/proc/cmdline"
    if [ $el7 -eq 1 ];then
        local flag=$(grep "crashkernel=auto" $file_name|head -1|wc -l)   
    elif [ $el6 -eq 1 ];then
        local flag=$(grep "crashkernel=256M" $file_name|head -1|wc -l)
    else
        local flag=$(grep "crashkernel=256M@64M" $file_name|head -1|wc -l)
    fi
     
    [ $flag -eq 1 ] && result 1 "The value of crashkernel in $file_name is right!" || result 2 "The value of crashkernel in $file_name is wrong!"
}

kdump_content_check()
{
    local device=$(df -lh /var |tail -1 |awk '{print $1}')
    local filesystem=$(mount|grep -w $device|awk '{print $(NF-1)}')
    local first_line="$device $filesystem"
    local second_line="path /var/crash"
    local third_line="core_collector makedumpfile -c --message-level 1 -d 31"
    local fourly_line="extra_modules mpt2sas mpt3sas megaraid_sas hpsa ahci"
    local five_line="default reboot"

    if [[ $(awk 'NR==1{print $1}' /etc/kdump.conf) == "$filesystem" ]] && \
        [[ $(awk 'NR==1{print $2}' /etc/kdump.conf) == "$device" ]] && \
        [[ $(awk 'NR==2{print}' /etc/kdump.conf) == "$second_line" ]] && \
        [[ $(awk 'NR==3{print}' /etc/kdump.conf) == "$third_line" ]] && \
        [[ $(awk 'NR==4{print}' /etc/kdump.conf) == "$fourly_line" ]] && \
        [[ $(awk 'NR==5{print}' /etc/kdump.conf) == "$five_line" ]]; \
    then
        result 1 "The content of /etc/kdump.conf is right!"
    else
        result 2 "The content of /etc/kdump.conf is wrong!"
    fi
}

kdump_service_check()
{
    if [ -e /etc/kdump.conf ];then
        result 1 "The /etc/kdump.conf is exist"
        kdump_content_check    
    else
        result 2 "No /etc/kdump.conf exist"
        exit $NO_FILE_EXIST
    fi
    
    if [ $el7 -eq 1 ];then
        service_flag=$(systemctl status kdump|grep Active|awk '{print $2}')
        enable_flag=$(systemctl status kdump|grep Loaded|awk '{print $4}'|awk -F';' '{print $1}')
        
        [[ "$service_flag" == "active" ]] && result 1 "Kdump service is running!" || result 2 "Please try to execute <systemctl start kdump>!"
        
        [[ "$enable_flag" == "enabled" ]] && result 1 "Kdump service is enabled!" || result 2 "Please try to execute <systemctl enable kdump>!"
    else
        enable_flag1=$(chkconfig --list kdump|awk '{print $5}'|awk -F: '{print $2}')
        enable_flag2=$(chkconfig --list kdump|awk '{print $7}'|awk -F: '{print $2}')
        service kdump status > /dev/null 2>&1
        [ $? -eq 0 ] && result 1 "Kdump service is running!" || result 2 "Please try to execute <service kdump start>!"
        
        [[ "$enable_flag1" == "on" ]] && [[ "$enable_flag2" == "on" ]] && result 1 "Kdump service is enabled!" || result 2 "Please try to execute <chkconfig --level 2345 kdump on>！"   
    fi
}

kdump_check()
{
    [ $setup_kdump -eq 0 ] && return
    [ "$reboot" == "before" ] && echo -e ">>>>>>>>>>>>Check the kdump before reboot<<<<<<<<<<<"
    [ "$reboot" == "after" ] && echo -e ">>>>>>>>>>>>Check the kdump after reboot<<<<<<<<<<<"
    kdump_service_check
    kdump_cmdline_check
    kdump_grub_check
}

usage()
{
    cat << EOF
    Usage:
        $(basename $0) -c                              setup and check conman before reboot
        $(basename $0) -k                              setup and check kdump before reboot
        $(basename $0) -c -t "ttyS0" -b "115200"       setup and check conman with device before reboot
        $(basename $0) -a                              check kdump and conman after reboot
EOF
    exit 1
}

[ $# -lt 1 ] && usage

while getopts ckat:b:h OPTION
do
    case $OPTION in
        c)
            setup_conman=1
            reboot="before";;
            
        k)
            setup_kdump=1
            reboot="before";;
        a)
            setup_conman=1
            setup_kdump=1
            reboot="after";;
        t)  tty=$OPTARG;;
        b)  bot=$OPTARG;;
        h)  usage;;
        *)  usage;;
    esac
done

conman_setup
conman_check
kdump_setup
kdump_check
