#!/bin/bash

ntp_servers=""
ntpstat_ip=""
ntpstat_res=""
ntpdate_res=""
ntpdate_ip=""
ntpq_ip=""
ntpq_ip_res=1
ntpq_offset=""
ntpq_clock_res=0
ntpq_offset_res=1
ntp_conf="/etc/ntp.conf"
node=""

ssh_check()
{
    ssh -o LogLevel=error -o ConnectTimeout=3 -o BatchMode=yes $node true
    [ $? -ne 0 ] && echo "Connect to $node failure!!!" && exit 1
}

ssh_cmd()
{
    local node="$1"
    local cmd="$2"
    ssh -o LogLevel=error $node "$cmd"
}

get_ntp_info()
{
    ntp_servers=$(ssh_cmd $node "cat $ntp_conf" | grep -v '#' | grep -v '127.127' |grep -v 'nopeer'|egrep 'server|peer' | awk '{print $2}')
}

ntp_service_check()
{
    el7=$(ssh_cmd $node "cat /etc/redhat-release"|grep " 7\."|wc -l)
    if [ $el7 -eq 1 ];then
        service_flag=$(ssh_cmd $node "systemctl status ntpd"|grep Active|awk '{print $2}')
        [[ "$service_flag" == "active" ]] && echo "NTP server is running!" || echo "Please try to exec <systemctl start ntpd>!"
    else
        service_flag=$(ssh_cmd $node "service ntpd status"|grep -c "running")
        [ $service_flag -eq 1 ] && echo "NTP server is running!" || echo "Please try to exec <service ntpd start>!"	
    fi
}

ntpq_check()
{
    local ntpq_res=$(ssh_cmd $node "ntpq -pn 2>/dev/null"|grep "\*")
    [ "$ntpq_res" == "" ] && return
    local sync_flag=$(echo $ntpq_res|grep -c ".LOCL.")
    [ $sync_flag -eq 1 ] && ntpq_clock_res=1 && return
    ntpq_ip=$(echo $ntpq_res|awk '{print $1}'|awk -F* '{print $2}')
    ntpq_offset=$(echo $ntpq_res|awk '{print $9}'|awk -F'.' '{print $1}')
    local signal=$(echo $ntpq_offset|grep -c '-')
    if [ $signal -eq 0 ];then
        [ $ntpq_offset -le 500 ] && ntpq_offset_res=0 || ntpq_offset_res=1
    else
        [ $ntpq_offset -ge -500 ] && ntpq_offset_res=0 || ntpq_offset_res=1
    fi
    for ip in $ntp_servers
    do
        [[ "$ntpq_ip" == "$ip" ]] && ntpq_ip_res=0
    done
}

ntpstat_check()
{
    local res=$(ssh_cmd $node 'ntpstat'|head -1)
    local sync_flag=$(echo $res|grep -c "synchronised to")
    local sync_res=$(echo $res|awk '{print $3}')
    
    [ $sync_flag -eq 0 ] && ntpstat_res=1 && return
    [ "$sync_res" == "local" ] && ntpstat_res=1
    [ "$sync_res" == "NTP" ] && ntpstat_ip=$(echo $res|grep -Eo '[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+') && ntpstat_res=0
}

ntpdate_check()
{
    local sync_res=0
    for ip in $ntp_servers
    do
        sync_res=$(ssh_cmd $node "ntpdate -q -u $ip 2>&1" | tail -1 | grep -c "$ip")
        [ $sync_res -eq 1 ] && ntpdate_res=0 && ntpdate_ip+="$ip "
    done
}

ping_check()
{
    for ip in $ntp_servers
    do
        ssh_cmd $node "ping -c 3 $ip" > /dev/null 2>&1
        [ $? -ne 0 ] && echo "Ping ntp server $ip failed, please fix it and try again ... " && exit 1
        echo "Ping ntp server $ip success!" 
    done
}

check_output()
{
    [ $ntpstat_res -eq 0 ] && echo "Connect to NTP server $ntpstat_ip success,ntpstat check PASS!" || echo "ntpstat check FAILURE!!!"
    [ $ntpdate_res -eq 0 ] && echo "Connect to NTP server $ntpdate_ip success,ntpdate check PASS!" || echo "ntpdate check FAILURE!!!"
    [ $ntpq_ip_res -eq 0 ] && echo "Connect to NTP server $ntpq_ip success,ntpq -pn check PASS!" || echo "ntpq -pn check FAILURE!!!"
    [ $ntpq_offset_res -eq 0 ] && echo "Current clock offset is $ntpq_offset ms!" || echo "Current clock offset is unknown,synchronization FAILURE!!!"
    [ $ntpq_clock_res -eq 1 ] && echo "Warning: Connect to local clock ,if this machine is not ntp server ,please check!!!"

    if [ $ntpstat_res -eq 0 ] && [ $ntpdate_res -eq 0 ] && [ $ntpq_ip_res -eq 0 ] && [ $ntpq_offset_res -eq 0 ];then
        echo ">>>>>>NTP client setup check success!!!"
    else
        echo ">>>>>>NTP client setup check FAILURE,please report to level 2 supporter!!!"   
    fi
}

usage()
{
    echo "sh ntp_check.sh -t <ip>"
    exit 1
}

main()
{   
    ssh_check
    get_ntp_info
    ping_check
    ntp_service_check
    ntpstat_check
    ntpdate_check
    ntpq_check
    check_output
}

while getopts t: OPTION
do
    case $OPTION in
        t) node="$OPTARG";;
        *) usage;;
    esac
done
[ "$node" == "" ] && usage || main
