#!/bin/bash
#########################################################################
# File Name: collect_project_info.sh
# Author: PeiYuan
# Mail: peiyuan.wc@alibaba-inc.com
# Description:
# Created Time: Wed Nov 22 17:31:44 2017
#########################################################################

TARGET_LISTS="./collect_ip_list"
iplist=""
version=2
TIME=$(date +%Y-%m-%d-%H-%M-%S)
TARBALL="cld_info_$TIME"

info()
{
    local msg=$1
    echo -e "$msg"
}
error()
{
    local msg="$1"
    info ""
    info "[Error]: $msg"
    exit 1
}
ssh_cmd()
{
    local node="$1"
    local cmd="$2"
    local sec=$3
    local pid=""
    local mpid=""
    local estatus=0

    [ "$sec" = "" ] && sec=600

    (ssh -o LogLevel=error -T root@$node <<EOF
    $cmd
EOF
)&
    pid=$!
    (sleep $sec && kill -9 $(pstree -p $pid | grep -oP '(?<=\()[0-9]+(?=\))') ) </dev/null >/dev/null 2>&1 &
    mpid=$!
    wait $pid >/dev/null 2>&1
    estatus=$?
    sleep 1
    disown $mpid
    kill -9 $(pstree -p $mpid | grep -oP '(?<=\()[0-9]+(?=\))') >/dev/null 2>&1
    case $estatus in
        137)
            info "ssh to $node run command: $cmd timeout with $sec !";;
        0)
            return 0;;
        *)
            info "ssh to $node run command: $cmd failed !";;
    esac
    return 1
}
ssh_check()
{
    local node=$1
    ssh -n -o LogLevel=error -o ConnectTimeout=3 -o BatchMode=yes root@$node true > /dev/null 2>&1
}
free_space_check()
{
    local dir=$(pwd)
    local target=20

    local threshold=$(($target * 1024 * 1024))
    local current=$(df -P $(dirname $dir) | grep -v Filesystem | awk '{print int($(NF-2))}')

    [ $current -lt $threshold ] && error "$node: The available space on $dir is less than ${target}G, Please cleanup for more."
}
generate_v2_servers_list()
{
    local server_list=$TARGET_LISTS
    local config=$(docker ps -a | grep api | awk '{print $1}' | xargs docker inspect | grep "L1root/L1tools/main/config" | awk -F : '{print $2}' | awk -F '"' '{print $2}' | sed -n 2p)
    local rtable="${config}/rtable.csv"
    local column=$(cat $rtable | head -1 | tr "," "\n"| awk 'BEGIN{IGNORECASE=1}{if($0 == "ip"){print NR}}')

    [ "$config" = "" ] && error "Generate server list error, can't find rtable !"

    info "Start generate server list ..."
    cat $rtable | grep -v sn_ | grep -i "$os_type" | awk -F, -v col=$column '{if($col != "")print $col}' | grep -ivE 'ip' > $server_list
    cp $server_list ./standard_ip_lists
}
generate_v3_servers_list()
{
    local server_list=$TARGET_LISTS
    curl -s localhost:7070/api/v5/BatchGetMachineInfo?attr=ip | grep ip | awk '{print $2}' | sed 's/\("\|,\)//g' > $server_list
    [ $? -ne 0 ] && error "Get ip lists failed ..."
    cp $server_list ./standard_ip_lists
}
generate_servers_list()
{
    if [ "$iplist" = "" ];then
        [ $version -eq 2 ] && generate_v2_servers_list
        [ $version -eq 3 ] && generate_v3_servers_list
    else
        TARGET_LISTS=$iplist
    fi
}
deploy_script()
{
    local node=$1
    local script_file="./cld_check.sh"
    scp $script_file "root@$node:/tmp/" > /dev/null 2>&1
}
cleanup_script()
{
    local node=$1
    ssh_cmd $node "rm -f /tmp/cld_check.sh"
}
execute_script_pull_tarball()
{
    local node=$1
    local html=""
    local json=""
    local err=0
    local errlog="/tmp/${node}_cld_error.log"
    ssh_cmd $node "sh /tmp/cld_check.sh -s small -c -r > /dev/null 2>$errlog"
    [ $? -ne 0 ] && return 1
    json=$(ssh_cmd $node "ls -rt /var/log/*.json" | tail -n 1)
    html=$(ssh_cmd $node "ls -rt /var/log/*.html" | tail -n 1)
    err=$(ssh_cmd $node "cat $errlog" | wc -l)

    [ "$json" = "" ] && echo "$node generate report failed ..." && return
    mkdir -p ./$TARBALL/
    ! scp -q "root@$node:${html}" ./$TARBALL/ && echo "copy $html failed ..."
    ! scp -q "root@$node:${json}" ./$TARBALL/ && echo "copy $json failed ..."
    [ "$json" != "" ] && ssh_cmd $node "rm -f $json" 
    [ "$html" != "" ] && ssh_cmd $node "rm -f $html" 
    [ $err -ne 0 ] && scp -q "root@$node:${errlog}" ./$TARBALL/
    ssh_cmd $node "rm -f $errlog"
}
start_running()
{
    local num=0
    generate_servers_list
    free_space_check
    
    for node in $(cat $TARGET_LISTS)
    do
        info ""
        info "$((++num)): Start collecting $node info ..."
    {
        ssh_check $node
        [ $? -ne 0 ] && echo "ssh to $node failed ..." && return
        deploy_script $node
        [ $? -ne 0 ] && echo "deploy script to $node failed ..." && return
        execute_script_pull_tarball $node
        info "$num: $node collecting done !"
        cleanup_script $node
    } &
    done
    wait
}
make_tarball()
{
    info ""
    info "Start creating tarball file ..."
    cp *_ip_list ./$TARBALL/ > /dev/null 2>&1
    [ -d "./$TARBALL" ] && tar -czf project_info_${TIME}.tar.gz ./$TARBALL
    [ $? -eq 0 ] && rm -rf "./$TARBALL" && info "tarball: project_info_${TIME}.tar.gz"
}
usage()
{
    cat << EOF
    Usage:
        $(basename $0)                           default for v2
        $(basename $0) -l <ip list file>         define ip lists file
        $(basename $0) -v 3                      collect v3 info, 2 or 3
EOF
    exit 1
}
######################## main #############################
while getopts v:l: OPTION
do
    case $OPTION in
        l) iplist="$OPTARG";;
        v) version=$OPTARG;;
        *) usage;;
    esac
done
start_running
make_tarball
