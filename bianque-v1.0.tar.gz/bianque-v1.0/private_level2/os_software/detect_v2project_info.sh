#!/bin/bash

###### LIST FILE ######
NTP_NEED_FIX_LIST="./ntp_need_fix_list"
NTP_NOX_LIST="./ntp_nox_list"
KDUMP_NEED_UPGRADE_LIST="./kdump_need_upgrade_list"
KDUMP_NOCONF_LIST="./kdump_noconf_list"
KDUMP_ENABLE_LIST="./kdump_enable_list"
KDUMP_DISABLE_LIST="./kdump_disable_list"
CONMAN_NOCONF_LIST="./conman_noconf_list"
CONMAN_ENABLE_LIST="./conman_enable_list"
CONMAN_DISABLE_LIST="./conman_disable_list"
STANDARD_LIST="./standard_ip_list"
EL5_LIST="./5u_list"
SSH_FAIL_LIST="./ssh_fail_list"
###### END LIST FILE ######
TARGET_LIST="./nc_ip_list"
filelist="LIST FILE"
iplist=""
version=2

info()
{
    local info=$1
    echo "$info"
}
ssh_cmd()
{
    local node=$1
    local cmd="$2"
    ssh -n -o LogLevel=error root@$node "$cmd"
}
ssh_check()
{
    local node=$1
    ssh -n -o LogLevel=error -o ConnectTimeout=3 -o BatchMode=yes root@$node true > /dev/null 2>&1
}
generate_v2_servers_list()
{
    local config=$(docker ps -a | grep api | awk '{print $1}' | xargs docker inspect | grep "L1root/L1tools/main/config" | awk -F : '{print $2}' | awk -F '"' '{print $2}' | sed -n 2p)
    local rtable="${config}/rtable.csv"
    local column=$(cat $rtable | head -1 | tr "," "\n"| awk 'BEGIN{IGNORECASE=1}{if($0 == "ip"){print NR}}')

    [[ "$config" == "" ]] && info "Generate server list error, can't find rtable !" && exit 2

    info "Start generate server list ..."
    cat $rtable | grep -v sn_ | awk -F, -v col=$column '{if($col != "")print $col}' | grep -ivE 'ip' > $TARGET_LIST
    cat $TARGET_LIST > ./standard_ip_list
}
generate_v3_servers_list()
{
    curl -s localhost:7070/api/v5/BatchGetMachineInfo?attr=ip | grep ip | awk '{print $2}' | sed 's/\("\|,\)//g' > $TARGET_LIST
    [ $? -ne 0 ] && error "Get ip lists failed ..."
    cat $TARGET_LIST > ./standard_ip_list
}
generate_servers_list()
{
    if [[ "$iplist" == "" ]];then
        [ $version -eq 2 ] && generate_v2_servers_list
        [ $version -eq 3 ] && generate_v3_servers_list
    else
        TARGET_LIST=$iplist && cat $TARGET_LIST > ./standard_ip_list
    fi
}
collect_ntp_info()
{
    local node=$1
    local is_el5=$(ssh_cmd $node "cat /etc/redhat-release"|grep -c ' 5\.')
    if [ $is_el5 -eq 1 ];then
        local ntp_is_x=$(ssh_cmd $node "grep -E ^OPTIONS /etc/sysconfig/ntpd 2>&1"|awk -F= '{print $2}'|tr -d \"|tr ' ' '\n'|grep -c "\-x")
        [ $ntp_is_x -eq 0 ] && echo $node >> $NTP_NOX_LIST
        local ntp_is_patch=$(ssh_cmd $node "cat /etc/init.d/ntpd 2>&1"|sed -n "/start()/,/}/"p|grep -c "#")
        [ $ntp_is_patch -lt 18 ] && echo $node >> $NTP_NEED_FIX_LIST
        echo $node >> $EL5_LIST
    fi
}
collect_kdump_info()
{
    local node=$1
    local is_el5=$(ssh_cmd $node "cat /etc/redhat-release"|grep -c ' 5\.')
    local content=$(ssh_cmd $node "cat /etc/kdump.conf 2>&1"|grep -vE "No|^$|#|Kdump_not_supported"|wc -l)
    local kdump_version=$(ssh_cmd $node "rpm -qa 2>/dev/null"|grep kexec-tools)
    if [ $is_el5 -eq 1 ];then
        [[ "$kdump_version" != "" ]] && [[ "$kdump_version" != "kexec-tools-1.102pre-165.alios5" ]] && echo $node >> $KDUMP_NEED_UPGRADE_LIST
    fi
    [ $content -eq 0 ] && echo $node >> $KDUMP_NOCONF_LIST
    ssh_cmd $node "service kdump status > /dev/null 2>&1"
    local kdump_status=$?
    [ $kdump_status -eq 0 ] && [ $content -gt 0 ] && echo $node >> $KDUMP_ENABLE_LIST
    [ $kdump_status -ge 1 ] && [ $content -gt 0 ] && echo $node >> $KDUMP_DISABLE_LIST
}
collect_conman_info()
{
    local node=$1
    local is_el5=$(ssh_cmd $node "cat /etc/redhat-release"|grep -c ' 5\.')
    local is_el6=$(ssh_cmd $node "cat /etc/redhat-release"|grep -c ' 6\.')
    local is_el7=$(ssh_cmd $node "cat /etc/redhat-release"|grep -c ' 7\.')
    [ $is_el5 -eq 1 ] || [ $is_el6 -eq 1 ] && local grub=$(ssh_cmd $node "grep vmlinuz-$(uname -r) /etc/grub.conf"|grep -c ttyS)
    [ $is_el7 -eq 1 ] && local grub=$(ssh_cmd $node "grep vmlinuz-$(uname -r) /etc/grub2.cfg"|grep -c ttyS)
    local securetty=$(ssh_cmd $node "grep -c ttyS /etc/securetty")
    local inittab=$(ssh_cmd $node "grep -c ttyS /etc/inittab")
    local printk1=$(ssh_cmd $node "cat /etc/sysctl.conf"|grep -c "kernel.printk = 5 4 1 5")
    local printk2=$(ssh_cmd $node "cat /proc/sys/kernel/printk"|grep -c "5	4	1	5")
    local cmdline=$(ssh_cmd $node "grep -c ttyS /proc/cmdline")
    local is_enable=$(ssh_cmd $node "ps -ef|grep -i agetty"|grep -v grep|awk '{print $6}'|grep -c ttyS)
    if [ $is_el5 -eq 1 ];then
        [ $grub -ge 1 ] && [ $securetty -ge 1 ] && [ $inittab -ge 1 ] && [ $printk1 -eq 1 ] && [ $printk2 -eq 1 ] && [ $is_enable -eq 0 ] && echo $node >> $CONMAN_DISABLE_LIST
    elif [ $is_el6 -eq 1 ];then
        [ $grub -ge 1 ] && [ $securetty -ge 1 ] && [ $printk1 -eq 1 ] && [ $printk2 -eq 1 ] && [ $is_enable -eq 0 ] && echo $node >> $CONMAN_DISABLE_LIST
    fi
    [ $cmdline -ge 1 ] && [ $securetty -ge 1 ] && [ $printk1 -eq 1 ] && [ $printk2 -eq 1 ] && [ $is_enable -ge 1 ] && echo $node >> $CONMAN_ENABLE_LIST
    [ $grub -eq 0 ] || [ $securetty -eq 0 ] || [ $printk1 -eq 0 ] || [ $printk2 -eq 0 ] &&  echo $node >> $CONMAN_NOCONF_LIST
}
clean_old_list_file()
{
    info "clean old list file..."
    local lists=$(sed -n "/## $filelist ##/,/## END $filelist ##/"p $0|grep -v "#"|awk -F"=" '{print $2}'|tr -d \")
    for file in $lists
    do
        [ -e $file ] && > $file
    done
}
generate_result_info()
{
    local result_file="./result.txt"
    local lists=$(sed -n "/## $filelist ##/,/## END $filelist ##/"p $0|grep -v "#"|awk -F"=" '{print $2}'|tr -d \")
    [ -e $result_file ] && > $result_file
    for file in $lists
    do
        [ ! -e $file ] && continue
        local filename=$(echo $file|awk -F/ '{print $2}')
        local value=$(wc -l $file|awk '{print $1}')
        [ -e $file ] && echo "$filename: $value" >> $result_file
    done
    [ -e $result_file ] && info "generate result file complete" || info "have no result file,please report to level 2!"
}
usage()
{
    cat << EOF
    Usage:
        $(basename $0)                      default detect v2 info, with -v 3 detect v3 info
        $(basename $0) -l <ip list file>    define ip list file
        $(basename $0) -v 3                 detect v3 info, only can be 2 or 3
EOF
    exit 1

}
start_running()
{
    for node in $(cat $TARGET_LIST)
    do
        info ""
        info "Start collecting $node info ..."
        ssh_check $node
        [ $? -ne 0 ] && echo "ssh to $node failed ..." && echo $node >> $SSH_FAIL_LIST && continue
        collect_ntp_info $node
        collect_kdump_info $node
        collect_conman_info $node
        info "$node collecting done !"
    done
}
########### main ###########
while getopts v:l: OPTION
do
    case $OPTION in
        l) iplist="$OPTARG";;
        v) version=$OPTARG;;
        *) usage;;
    esac
done

clean_old_list_file
generate_servers_list
start_running
generate_result_info
