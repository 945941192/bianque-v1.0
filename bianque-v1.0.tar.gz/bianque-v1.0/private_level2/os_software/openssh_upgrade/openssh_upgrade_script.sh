#!/bin/bash
#########################################################################
# File Name: openssh_upgrade_script.sh
# Author: PeiYuan
# Mail: peiyuan.wc@alibaba-inc.com
# Description: upgrade openssh rpm
# Created Time: Wed Aug  9 17:21:45 2017
#########################################################################
alios5u7="alios5u7"
alios6u2="alios6u2"
tmp_dir="/tmp/ssh_upgrade"
suffix="$(date "+%Y-%m-%d-%H-%M-%S").tar.gz"

info()
{
    local info=$1
    echo "$info"
}
error()
{
    local info="$1"
    info ""
    info "[Error]: $info"
    exit 1
}
ssh_cmd()
{
    local node=$1
    local cmd="$2"

    ssh -o LogLevel=error root@$node "$cmd"

    if [ "$?" != "0" ] && [ "$2" != "ignore" ];then
        error "cmd : $1 failed !"
    fi
}

generate_servers_list()
{
    local os_type=$1
    local server_list=$2
    local config=$(docker ps -a | grep api | awk '{print $1}' | xargs docker inspect | grep "L1root/L1tools/main/config" | awk -F : '{print $2}' | awk -F '"' '{print $2}' | sed -n 2p)
    local rtable="${config}/rtable.csv"
    local column=$(cat $rtable | head -1 | tr "," "\n"| awk 'BEGIN{IGNORECASE=1}{if($0 == "ip"){print NR}}')

    [ "$config" = "" ] && error "Generate server list error !"

    info "Start generate $os_type server list ..."
    > $server_list
    for ip in $(cat $rtable | grep -v sn_ | grep -i "$os_type" | awk -F, -v col=$column '{if($col != "")print $col}' | grep -ivE 'ip')
    do
        local ok=$(ssh -o BatchMode=yes -o LogLevel=error -o ConnectTimeout=3 root@$node "echo ok" 2>&1)
        local need_upgrade=$(ssh_cmd $ip "ssh -V 2>&1" | grep -ic "OpenSSH_7.3p1")
        [ "$ok" != "ok" ] && info "Server $ip ssh login failed, skip ..." && continue 
        [ $need_upgrade -ne 0 ] && info "Server $ip openssh upgraded, skip ..." && continue
        echo $ip >> $server_list
    done
    [[ $(cat $server_list | wc -l) -eq 0 ]] && echo "Notes: $server_list is empty"
}
copy_rpm_to_server()
{
    local node=$1
    local os_type=$2
    info "Copy rpm to server $node ..."
    ssh_cmd $node "mkdir -p ${tmp_dir}"
    scp -rq ./$os_type root@${node}:${tmp_dir}/
    [ $? -ne 0 ] && error "Copy rpm to $node failed please check it, exit ..."
}
backup_config_file()
{
    local node=$1
    local os_type=$2
    local stuff=$3
    info "Backup server $node $stuff ..."
    ssh_cmd $node "tar -pczf ${stuff}.${suffix} $stuff >/dev/null 2>&1 "
    ssh_cmd $node "mv ${stuff}.${suffix} ${tmp_dir}/${os_type}/"
}
backup_config_files()
{
    local node=$1
    local os_type=$2
    backup_config_file $node $os_type "/etc/ssh"
    backup_config_file $node $os_type "/root/.ssh"
}

upgrade_openssh()
{
    local node=$1
    local os_type=$2
    local i=0
    
    info "Start to upgrade $node openssh ..."

    cat > ./upgrade.sh << EOF
    cd ${tmp_dir}/$os_type
    sleep 2
    /etc/init.d/sshd stop
    rpm -Uvh *.rpm
    rm -rf ./ssh
    mv /etc/ssh/ ./
    tar -pxzf "ssh.${suffix}" -C /
    /etc/init.d/sshd start
    success=\$(/etc/init.d/sshd status | grep -c running)
    if [ \$success -ne 1 ];then
        echo "Upgrade failed restore /etc/ssh ..."
        rm -rf /etc/ssh
        /bin/mv ./ssh /etc/ 
        /etc/init.d/sshd restart
    fi
EOF
    chmod 755 ./upgrade.sh
    scp -o LogLevel=error ./upgrade.sh root@$node:${tmp_dir}/$os_type/
    ssh -o LogLevel=error root@$node "nohup sh ${tmp_dir}/$os_type/upgrade.sh > ${tmp_dir}/$os_type/upgrade.log 2>&1 &"

    while [ 1 ];
    do
        sleep 10
        info "Checking upgrade ..."
        ssh -o LogLevel=error -o ConnectTimeout=3 root@$node true > /dev/null 2>&1
        [ $? -eq 0 ] && break
        i=$(($i+1))
        [ $i -eq 3 ] && error "$node ssh upgrade failed, please fix by manually !"
    done
}
upgrade_postcheck()
{
    local node=$1
    local success=$(ssh_cmd $node "ssh -V 2>&1" | grep -ic "OpenSSH_7.3p1")
    [ $success -eq 1 ] && info "Upgrade server $node openssh success !" && return
    error "Upgrade server $node openssh failed, please check it by manually ..."
}
upgrade_cleanup()
{
    local node=$1
    local os_type=$2
    [ "$tmp_dir" != "/" ] && ssh_cmd $node "rm -rf ${tmp_dir}"
}
precheck_os()
{
    local node=$1
    local os_type=$2
    local el5=$(ssh_cmd $node "cat /etc/redhat-release" | grep -c '5\.')
    local el6=$(ssh_cmd $node "cat /etc/redhat-release" | grep -c '6\.')

    case "$os_type" in
        "alios5u7")
            [ $el5 -ne 1 ] && error "Server $node is not $os_type, please check it ..."
            ;;
        "alios6u2")
            [ $el6 -ne 1 ] && error "Server $node is not $os_type, please check it ..."
            ;;
    esac

}
do_rolling_upgrade()
{
    local os_type=$1
    local server_list="/tmp/${os_type}_list"
    
    generate_servers_list $os_type $server_list
    for node in $(cat $server_list)
    do
        info ""
        info "Start upgrade server $node openssh ..."
        precheck_os $node $os_type
        copy_rpm_to_server $node $os_type
        backup_config_files $node $os_type
        upgrade_openssh $node $os_type
        upgrade_postcheck $node $os_type
        upgrade_cleanup $node $os_type
    done
}

##################### main #####################
do_rolling_upgrade $alios5u7
do_rolling_upgrade $alios6u2
