#!/usr/bin/env python
# coding=utf-8

from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
import subprocess
import logging
import sys
import getopt
import base64
import threading

#global 
'''获取脚本参数'''
arg_num = len(sys.argv)    
cloud_type = None
version_type = None
project_name = None

#OSS 对象存储
OSSBUCKET = {
                'BUCKETNAME' : '//135400/web_bucket/',   
                'HOST'       : 'b3NzLWNuLWhhbmd6aG91LXptZi5hbGl5dW5jcy5jb20=',
                'ID'         : 'TFRBSTZhUHowbzFnb1Jacg==',   
                'KEY'        : 'MkhxR21ldmNuYXM3bWc2c3NLODE2TzF6V3ViV0w2'
            }

###########################################################################################
logging.basicConfig(level=logging.INFO,
                format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                datefmt='%a, %d %b %Y %H:%M:%S',
                filename='/var/weizhanbiao/project_db.log',
                filemode='a')


_ENGINE = create_engine("mysql+mysqldb://root:mysql@localhost:3306/os_db?charset=utf8", 
                max_overflow=5,
                encoding="utf8",
                echo=False, )

DBSession = sessionmaker(bind=_ENGINE,autoflush=False)

###########################################################################################

"""获取项目包中所有主机 html 和 json 文件名"""
def get_project_html_json_name(project_ball_dir):
    try:
        html_json_file_name_list = subprocess.check_output("ls {project_ball_dir} 2>/dev/null".format(project_ball_dir=project_ball_dir),shell=True).split("\n")[:-1]
    except Exception as e:
        print "请检查项目包路径是否传入正确"
        sys.exit()
    html_file_name_list = [project_ball_dir+'/'+ _ for _ in html_json_file_name_list if _.endswith("html") ]
    json_file_name_list = [ project_ball_dir+'/'+_ for _ in html_json_file_name_list if _.endswith("json") ]
    return html_file_name_list,json_file_name_list

"""解析json文件""" 
def analysis_json_file_name_list_and_save_db(id_dict,json_file_name_list):
    session = DBSession()
#analysis Field information
    for json_file_name in json_file_name_list:
        try:
            json_info_dict = eval(subprocess.check_output("cat {json_file_name}".format(json_file_name=json_file_name),shell=True).replace("\n",""))
        except Exception as e:
            continue
        host_info_dict = json_info_dict.get("HOSTINFO")
        """ if health num is 0 not storage """ 
        health_index_num = host_info_dict.get("os_health")
        if health_index_num == 0:
            continue
#save host_name_info table
        host_name  = host_info_dict.get("hostname")
        host_project_obj_id = id_dict.get("project_id") 
        '''  一个项目主机名不能相同，表中没有才增加 '''
        find_sql = "select * from host_name_info where host_project_obj_id=:host_project_obj_id and host_address=:host_address"
        #判断是否存在zhe台主机  有就更新  没有就存主机表
        if  session.execute(find_sql,{"host_project_obj_id":host_project_obj_id,"host_address":host_name}).first():
            #print "%s主机存在"%host_name
            pass
        else:
            sql = "insert into host_name_info (host_address,host_project_obj_id) values(:host_name,:host_project_obj_id)"
            session.execute(sql,{"host_name":host_name,"host_project_obj_id":host_project_obj_id})
            print "%s主机信息入库"%host_name
            session.commit()
#save host_check_date_info_0 <0-9>
# 如果有就更新 没就增加
        find_host_name_id_sql = "select host_id from host_name_info where host_project_obj_id=:host_project_obj_id and host_address=:host_address"
        host_name_id = session.execute(find_host_name_id_sql,{"host_project_obj_id":host_project_obj_id,"host_address":host_name}).first().host_id
        tag = host_name_id % 10
        host_check_date_info_table_name = "host_check_date_info_{tag}".format(tag=tag)
        host_check_date = json_file_name.split(".")[-2]
        health_index_num = host_info_dict.get("os_health")
        find_sql = "select * from {host_check_date_info_table_name} where host_name_obj_id=:host_name_id and host_check_date=:host_check_date".format(host_check_date_info_table_name=host_check_date_info_table_name)
        if session.execute(find_sql,{"host_name_id":host_name_id,"host_check_date":host_check_date}).first():
            #存在就更新
            pass
        else:
            sql = "insert into {host_check_date_info_table_name} (host_check_date,host_name_obj_id,health_index_num,collection_log_tarball_link) values(:host_check_date,:host_name_obj_id,:health_index_num,'')".format(host_check_date_info_table_name=host_check_date_info_table_name)
            session.execute(sql,{"host_check_date":host_check_date,"host_name_obj_id":host_name_id,"health_index_num":health_index_num})
            session.commit()
            print "---------主机< %s >信息--检测日期< %s >入库"%(host_name,host_check_date)
#save host_info_0 <0-9> 
# 如果有就更新 没有就增加
        server = host_info_dict.get("server_model")
        processors = host_info_dict.get("processor_model")
        memory = host_info_dict.get("memory_model")
        disk_controller = host_info_dict.get("dsk_crtl_modle")
        system_info = host_info_dict.get("os_release")
        kernel_version = host_info_dict.get("os_kernel")
        bios_version = host_info_dict.get("bios_type")
        host_check_date_obj_id = session.execute("select host_check_date_id from {host_check_date_info_table_name} where host_name_obj_id=:host_name_obj_id and host_check_date=:host_check_date".format(host_check_date_info_table_name=host_check_date_info_table_name),{"host_name_obj_id":host_name_id,"host_check_date":host_check_date}).first().host_check_date_id
        host_info_table_name = "host_info_{tag}".format(tag=tag)
        find_sql = "select * from {host_info_table_name} where host_check_date_obj_id=:host_check_date_obj_id".format(host_info_table_name=host_info_table_name)
        if session.execute(find_sql,{"host_check_date_obj_id":host_check_date_obj_id}).first():
            pass
        else:
            sql = "insert into {host_info_table_name} (server,processors,memory,disk_controller,system_info,kernel_version,bios_version,host_check_date_obj_id) values(:server,:processors,:memory,:disk_controller,:system_info,:kernel_version,:bios_version,:host_check_date_obj_id)".format(host_info_table_name=host_info_table_name)
            session.execute(sql,{"server":server,"processors":processors,"memory":memory,"disk_controller":disk_controller,"system_info":system_info,"kernel_version":kernel_version,"bios_version":bios_version,"host_check_date_obj_id":host_check_date_obj_id})
            session.commit()
            print "         |"
            print "         %s--------------system info "%host_check_date

#save host_check_info_0 <0-9>
        host_check_info_list = json_info_dict.get("CHECKINFO")
        host_check_info_table_name = "host_check_info_{tag}".format(tag=tag)
        for _ in host_check_info_list:
            name = _.get("name")
            status = _.get("status")
            reason = _.get("info")
            find_sql = "select * from {host_check_info_table_name} where host_check_date_obj_id=:host_check_date_obj_id and name=:name".format(host_check_info_table_name=host_check_info_table_name)
            if session.execute(find_sql,{"host_check_date_obj_id":host_check_date_obj_id,"name":name}).first():
                pass
            else:
                sql = "insert into {host_check_info_table_name} (name,status,reason,host_check_date_obj_id,host_name_obj_id) values(:name,:status,:reason,:host_check_date_obj_id,:host_name_obj_id)".format(host_check_info_table_name=host_check_info_table_name)
                session.execute(sql,{"name":name,"status":status,"reason":reason,"host_check_date_obj_id":host_check_date_obj_id,"host_name_obj_id":host_name_id})
                session.commit()
                print "             |"
                print "             --------------------------------------------检测信息< %s >入库"%name
    session.close()


"""获取脚本参数，解析 <云> <版本> <项目> <id>"""
def analysis_script_arg_id(cloud_type,version_type,project_name):
    session = DBSession()
    cloud_id = session.execute("select cloud_id from cloud_type where cloud_type=:cloud_type",{"cloud_type":cloud_type}).first().cloud_id
    version_id = session.execute("select version_id from cloud_version where cloud_obj_id=:cloud_id and version_type=:version_type",{"cloud_id":cloud_id,"version_type":version_type}).first().version_id
    try:
        project_id = session.execute("select project_id from project_info where project_version_obj_id=:version_id and project_name=:project_name",{"version_id":version_id,"project_name":project_name}).first().project_id
    except Exception as e:
        print "项目不存在，请在扁鹊创建项目"
        sys.exit(1)
    session.close()
    return {
            "cloud_id"   :  cloud_id,
            "version_id" :  version_id,
            "project_id" :  project_id,
            }
    
"""push oss and save check_date table db"""
def push_oss_and_update_db(id_dict,html_file_name_list):
    session = DBSession()
    project_id = id_dict.get("project_id") 

    for html_file_obj in html_file_name_list:
        # host_name = html_file_obj.split('/')[-1].split("_")[0]
        """由于有的json格式不争取 导致eval无法解析"""
        try:
            host_name = eval(subprocess.check_output("cat {json_file}".format(json_file=html_file_obj.replace("html","json")),shell=True).replace("\n","")).get("HOSTINFO").get("hostname")
        except Exception as e:
            continue
        host_check_date = html_file_obj.split('.')[-2]
        #判断 这台主机 和 这个收集检查时间 判断是否存在
        find_host_sql = "select * from host_name_info where host_address=:host_name and host_project_obj_id=:project_id"
        if session.execute(find_host_sql,{"host_name":host_name,"project_id":project_id}).first():
            host_name_id = session.execute(find_host_sql,{"host_name":host_name,"project_id":project_id}).first().host_id
            tag = host_name_id % 10
            host_check_date_info_table_name = "host_check_date_info_{tag}".format(tag=tag)
            find_check_date_sql = "select * from {host_check_date_info_table_name} where host_name_obj_id=:host_name_obj_id and host_check_date=:host_check_date".format(host_check_date_info_table_name=host_check_date_info_table_name)
            check_date_exis_tag = 1 if session.execute(find_check_date_sql,{"host_name_obj_id":host_name_id,"host_check_date":host_check_date}).first() else 0
            find_check_report_link_sql = "select check_report_link from {host_check_date_info_table_name} where host_name_obj_id=:host_name_obj_id and host_check_date=:host_check_date".format(host_check_date_info_table_name=host_check_date_info_table_name)
            check_report_link_data = session.execute(find_check_report_link_sql,{"host_name_obj_id":host_name_id,"host_check_date":host_check_date}).first().check_report_link
            check_report_link_tag = 1 if check_report_link_data == None or check_report_link_data=="push oss fail" else 0
            if check_date_exis_tag == 1 and check_report_link_tag == 1:
                check_report_link = get_check_report_link(html_file_obj)
                sql = "update {host_check_date_info_table_name} set check_report_link=:check_report_link where host_name_obj_id=:host_name_obj_id and host_check_date=:host_check_date".format(host_check_date_info_table_name=host_check_date_info_table_name)
                session.execute(sql,{"check_report_link":check_report_link,"host_name_obj_id":host_name_id,"host_check_date":host_check_date}) 
                session.commit()
            else:
                print "请勿重复上传 html文件到oss上"
            
        else:
            print "没有主机信息"
    session.close()
   

 
def get_check_report_link(html_file_dir):
    print "push oss ",html_file_dir
    HOST = base64.b64decode(OSSBUCKET.get('HOST'))
    ID = base64.b64decode(OSSBUCKET.get('ID'))
    KEY = base64.b64decode(OSSBUCKET.get('KEY'))
    BUCKETNAME = OSSBUCKET.get('BUCKETNAME')
    try:
        upload_oss_back_info = subprocess.check_output("osscmd put {html_file_dir} oss:{BUCKETNAME} --host {HOST} --id {ID} --key {KEY}".format(BUCKETNAME=BUCKETNAME,html_file_dir=html_file_dir,HOST=HOST,ID=ID,KEY=KEY),shell=True)
        html_url = upload_oss_back_info.split("URL is: ")[1].split('\n')[0].replace("%2F","/")
        print "push ok"
    except Exception as e:
        html_url = "push oss fail"
        print e                                                                                                                         
    return html_url 

def run_more_thread(html_file_dir_list,id_dict,th_num):
    th_list = []
    num = len(html_file_dir_list)/th_num
    for i in range(0,th_num):
        if i == th_num-1:
            file_list = html_file_dir_list[i*num:]
        else:
            file_list = html_file_dir_list[i*num:(i+1)*num]
        th_list.append(threading.Thread(target=push_oss_and_update_db,args=(id_dict,file_list)))
    for t in th_list:
        t.start()
    for t in th_list:
        t.join()

############################################################################################

"""
db:
    os_db
table:
     cloud_type             
     cloud_version
     project_info
     host_name_info             <id%10  取余数为check_date表名tail>
     host_check_date_info_0     <0-9>
     host_info_0                <0-9>
     host_check_info_0          <0-9>
"""
def usage():
    file_name = sys.argv[0]
    print "Usage:"
    print "         %s -h                                              display help information ."%file_name
    print "         %s -c <cloud type>                                 cloud type info ."%file_name
    print "         %s -v <version type>                               version type info ."%file_name
    print "         %s -p <project name>                               project name info ."%file_name
    print "         %s -f <project log ball dir>                       project log ball dir info."%file_name
    print "Example:"
    print "         python  %s -c 专有云 -v v2 -p 北宫门 -f /var/log/tarball"%file_name
    sys.exit(0)



if __name__ == "__main__":
    
    try:
        opts,args = getopt.getopt(sys.argv[1:],"c:v:p:f:h")
        for op,value in opts:
            if op == "-c":
                cloud_type = value
            elif op == "-v":
                version_type = value
            elif op == "-p":
                project_name = value
            elif op == "-f":
                project_ball_dir = value
            elif op == "-h":
                usage()
    except Exception as e:
        print "请输入正确的参数" 
        usage()

    if arg_num == 1 or cloud_type == None or version_type == None or project_name == None or project_ball_dir == None :
        usage()
    '''获取脚本参数id'''
    id_dict = analysis_script_arg_id(cloud_type,version_type,project_name)
    '''获取json 和 html 文件名（全路径）list'''
    html_file_name_list,json_file_name_list = get_project_html_json_name(project_ball_dir)
    '''解析json 并入库'''
    analysis_json_file_name_list_and_save_db(id_dict,json_file_name_list)
    '''(threading)push oss and save check_date table db;'''
    run_more_thread(html_file_name_list,id_dict,4)

    
