#!/usr/bin/env python
# coding=utf-8
from __future__ import absolute_import, unicode_literals
import os
from celery import Celery,platforms

from django.conf import settings

from celery.schedules import crontab
from datetime import timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'os_web.settings')
platforms.C_FORCE_ROOT = True
app = Celery('os_web')

#将settings对象作为参数传入
app.config_from_object('django.conf:settings',)

#celery 自动发现任务: APP/tasks.py
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)

#设置定时参数
app.conf.update(
    #celery 路径
    CELERY_ROUTES={
        "proj.tasks.add": {"queue": "hipri"},  # 把add任务放入hipri队列
        # 需要执行时指定队列 add.apply_async((2, 2), queue='hipri')
    },
    #celery beat 调度
    CELERYBEAT_SCHEDULE={
        #app:report
        "mistakes-push": {
            "task": "report.tasks.test_task",
            "schedule": timedelta(minutes=60),
        },
        "mistakes-asy-json": {
            "task": "report.tasks.asy_json",
            "schedule": timedelta(minutes=180),
        },
        "mistakes-asy-host-model": {
            "task": "report.tasks.asy_update_host_name_model",
            "schedule": timedelta(minutes=180),
        },
        #app:query asy  
        "query-asy-update_query_host_tables": {
            "task": "query.tasks.update_query_host_tables",
            "schedule": timedelta(minutes=180),
        },
    },
    )


@app.task(bind=True)
def debug_task(self):
    print('Request: {0!r}'.format(self.request))

