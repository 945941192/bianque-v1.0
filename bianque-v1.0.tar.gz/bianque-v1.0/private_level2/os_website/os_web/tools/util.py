#!/usr/bin/env python
# coding=utf-8

import subprocess

from os_web.settings import PROJEKT_DIR,FilePath
from aliyun.models import CheckItemNameMap
from check.models import UploadTarBallInfo,ScriptToolsInfo


def pull_gitlab():

    ''' 
        pull gitlab Latest code
    '''

    res = subprocess.call("cd %s && git pull origin master"%PROJEKT_DIR,shell=True)

def down_tarball_push_oss(tarball,save_db=0):

    """
    1 down tarball to /var/log
    2 push tarball and check_report.html to oss
    3 use orm save sql_db
    """

    full_path_tarball = FilePath + tarball.name
    #save /var/log
    with open(full_path_tarball,"w") as pic:
        for c in tarball.chunks():
            pic.write(c)
    #check tar_ball
    pull_gitlab()
    cld_check_script_path = subprocess.check_output("find {PROJEKT_DIR} -name cld_check.sh".format(PROJEKT_DIR=PROJEKT_DIR),shell=True).strip()
    check_status = subprocess.call("sh {cld_check_script_path} -c -r  {full_path_tarball}".format(cld_check_script_path=cld_check_script_path,full_path_tarball=full_path_tarball),shell=True) 
    #tar -zxf tarball 
    tar_x_tarball = subprocess.call("cd {FilePath} && tar -zxf {full_path_tarball}".format(FilePath=FilePath,full_path_tarball=full_path_tarball),shell=True)
    #save
    print tarball.name,save_db,"$"*80

""" 检查项对应中文名称 """
def check_item_name_map(item=None):
    check_item_name_dict = dict()
    for obj in CheckItemNameMap.objects.all():
        check_item_name_dict[obj.check_item_name_EN] = obj.check_item_name_CN
    #print check_item_name_dict
    if item in check_item_name_dict:
        print "zai "
        return check_item_name_dict[item]
    else:
        print "no"
        return item



