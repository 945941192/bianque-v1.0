# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0009_auto_20171130_1402'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hostcheckinfo_0',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_1',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_2',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_3',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_4',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_5',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_6',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_7',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_8',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_9',
            name='name',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0', blank=True),
        ),
    ]
