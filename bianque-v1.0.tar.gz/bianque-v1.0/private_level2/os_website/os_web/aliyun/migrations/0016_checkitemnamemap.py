# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0015_projectinfo_asy_json'),
    ]

    operations = [
        migrations.CreateModel(
            name='CheckItemNameMap',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_name_EN', models.CharField(max_length=80, null=True, verbose_name=b'\xe6\xa3\x80\xe6\x9f\xa5\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0EN', blank=True)),
                ('check_item_name_CN', models.CharField(max_length=80, null=True, verbose_name=b'\xe6\xa3\x80\xe6\x9f\xa5\xe9\xa1\xb9\xe5\x90\x8d\xe7\xa7\xb0CN', blank=True)),
            ],
            options={
                'db_table': 'check_item_name_map',
                'verbose_name_plural': '<8> CheckItemNameMap(check item EN name map CN name)',
            },
        ),
    ]
