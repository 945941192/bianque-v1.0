# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0010_auto_20171130_1736'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hostcheckinfo_0',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_1',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_2',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_3',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_4',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_5',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_6',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_7',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_8',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
        migrations.AlterField(
            model_name='hostcheckinfo_9',
            name='reason',
            field=models.TextField(max_length=1000, null=True, verbose_name=b'\xe9\x94\x99\xe8\xaf\xaf\xe4\xbf\xa1\xe6\x81\xaf', blank=True),
        ),
    ]
