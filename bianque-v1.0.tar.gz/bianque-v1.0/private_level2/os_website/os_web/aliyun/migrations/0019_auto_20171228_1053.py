# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0018_auto_20171228_1052'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='queryhostview',
            name='host_project_obj',
        ),
        migrations.DeleteModel(
            name='QueryHostView',
        ),
    ]
