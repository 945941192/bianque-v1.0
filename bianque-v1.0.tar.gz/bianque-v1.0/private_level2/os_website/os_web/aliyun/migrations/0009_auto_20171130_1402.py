# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0008_auto_20171127_1747'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hostcheckdateinfo_0',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_1',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_2',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_3',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_4',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_5',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_6',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_7',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_8',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
        migrations.AlterField(
            model_name='hostcheckdateinfo_9',
            name='host_check_date',
            field=models.CharField(max_length=800, verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
    ]
