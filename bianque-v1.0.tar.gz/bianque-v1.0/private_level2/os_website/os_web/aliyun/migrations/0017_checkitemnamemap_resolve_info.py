# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0016_checkitemnamemap'),
    ]

    operations = [
        migrations.AddField(
            model_name='checkitemnamemap',
            name='resolve_info',
            field=models.TextField(null=True, verbose_name=b'\xe6\x95\x85\xe9\x9a\x9c\xe8\xa7\xa3\xe5\x86\xb3\xe6\x96\xb9\xe6\xa1\x88', blank=True),
        ),
    ]
