# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0007_auto_20171101_1737'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='hostinfo_6',
            options={'verbose_name_plural': '<6.6> HostInfo_6(\u4e3b\u673a\u4fe1\u606f\u88686)'},
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_0',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_1',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_2',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_3',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_4',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_5',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_6',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_7',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_8',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
        migrations.AddField(
            model_name='hostcheckdateinfo_9',
            name='collection_log_tarball_link',
            field=models.CharField(max_length=800, null=True, verbose_name=b'\xe6\x94\xb6\xe9\x9b\x86\xe7\xb3\xbb\xe7\xbb\x9f\xe6\x97\xa5\xe5\xbf\x97tarball\xe4\xb8\x8b\xe8\xbd\xbd\xe9\x93\xbe\xe6\x8e\xa5', blank=True),
        ),
    ]
