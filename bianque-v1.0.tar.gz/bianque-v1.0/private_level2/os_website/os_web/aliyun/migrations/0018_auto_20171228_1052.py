# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0017_checkitemnamemap_resolve_info'),
    ]

    operations = [
        migrations.CreateModel(
            name='QueryHostView',
            fields=[
                ('host_id', models.AutoField(max_length=8, serialize=False, verbose_name=b'ID', primary_key=True)),
                ('host_address', models.CharField(max_length=1000, null=True, verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xba\xe5\x9c\xb0\xe5\x9d\x80', blank=True)),
                ('host_description', models.CharField(max_length=1000, null=True, verbose_name=b'\xe6\x8f\x8f\xe8\xbf\xb0', blank=True)),
                ('host_project_obj', models.ForeignKey(to='aliyun.ProjectInfo')),
            ],
            options={
                'db_table': 'query_host_view',
                'verbose_name_plural': '<9> query host view table',
            },
        ),
        migrations.AddField(
            model_name='hostnameinfo',
            name='newest_check_health_num_asy',
            field=models.IntegerField(default=0, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe5\x81\xa5\xe5\xba\xb7\xe6\x8c\x87\xe6\x95\xb0'),
        ),
    ]
