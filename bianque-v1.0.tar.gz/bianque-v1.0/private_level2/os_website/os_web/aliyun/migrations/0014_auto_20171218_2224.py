# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0013_auto_20171214_1814'),
    ]

    operations = [
        migrations.AddField(
            model_name='cloudtype',
            name='asy_json',
            field=models.TextField(default=b'', verbose_name=b'\xe5\xbc\x82\xe6\xad\xa5\xe5\x85\xa5\xe5\xba\x93\xe6\x95\xb0\xe6\x8d\xae'),
        ),
        migrations.AddField(
            model_name='cloudversion',
            name='asy_json',
            field=models.TextField(default=b'', verbose_name=b'\xe5\xbc\x82\xe6\xad\xa5\xe5\x85\xa5\xe5\xba\x93\xe6\x95\xb0\xe6\x8d\xae'),
        ),
    ]
