# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0020_hostnameinfo_newest_check_date_asy'),
    ]

    operations = [
        migrations.AddField(
            model_name='hostnameinfo',
            name='oldest_check_date_asy',
            field=models.CharField(default=0, max_length=1000, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe7\x9b\x91\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f'),
        ),
    ]
