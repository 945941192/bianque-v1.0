# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('aliyun', '0012_auto_20171205_1340'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hostnameinfo',
            name='host_address',
            field=models.CharField(max_length=1000, null=True, verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xba\xe5\x9c\xb0\xe5\x9d\x80', blank=True),
        ),
    ]
