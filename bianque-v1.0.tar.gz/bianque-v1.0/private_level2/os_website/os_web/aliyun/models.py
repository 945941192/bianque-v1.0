#coding=utf-8

from django.db import models
from django.utils.timezone import localtime
from datetime import datetime
import time
from collections import Counter

class CloudType(models.Model):
    cloud_id = models.AutoField("ID",primary_key=True,max_length=8)
    cloud_type = models.CharField("云类型",blank=True, null=True,max_length=8)
    cloud_description = models.CharField("描述",blank=True, null=True,max_length=1000)
    creat_time = models.DateTimeField("创建日期",auto_now=True)
    """异步更新字段"""
    """
        {
            "check_item_stat":{"history":50,"netstat":800}
        }
    """
    asy_json = models.TextField("异步入库数据",default="") 

    class Meta:
        db_table = "cloud_type"
        verbose_name_plural = "<1>  CloudType(专有云或公有云信息)"
      
    """云类型 每个版本中每台主机最新一次检查项的统计（统计check status is 1）"""
    """return :  [(u'kdump_conf', 119), (u'cat_proc_cmdline', 119), (u'dns_info', 117), (u'kdump_status', 108), (u'ip_route_show', 106)]  """
    @property
    def cloud_host_info_version_stat(self):
        version_stat_list = [ dict(_.check_host_info_version_stat) for _ in CloudVersion.objects.filter(cloud_obj__cloud_id=self.cloud_id)]
        dict1 = {}

        for dict_obj in version_stat_list:
            dict1 = dict(Counter(dict1)+Counter(dict_obj))
        as_dict = sorted(dict1.iteritems(),key=lambda d:d[1],reverse=True) #字典排序
        return as_dict

    def __unicode__(self):         
        return self.cloud_type 

class CloudVersion(models.Model):
    version_id = models.AutoField("ID",primary_key=True,max_length=8)
    version_type = models.CharField("版本信息",max_length=8)
    cloud_obj = models.ForeignKey(CloudType) 
    version_description = models.CharField("版本描述",blank=True, null=True,max_length=1000)
    """异步更新字段"""
    """
        {
            "newest_health":80,
            "project_count_db":80,
            "host_count_db":80,
            "health_range_info_db":{"0-60":30,"60-80":20,"80-100":100},
            "check_item_stat":[["kdump_conf", 835], ["dns_info", 823], ["cat_proc_cmdline", 622], ["kdump_status", 477], ["ip_route_show", 351], ["dmesg", 105], ["fstab_info", 23], ["ifconfig", 21], ["docker_info", 18], ["bonding_info", 13], ["ipmitool_lan_print_1", 9], ["copy_system_files", 7], ["netstat_anpo", 5], ["ipmitool_sel_elist", 4], ["uptime", 1], ["df_h", 1]]
    """
    asy_json = models.TextField("异步入库数据",default="") 

    class Meta:
        db_table = "cloud_version"
        verbose_name_plural = "<2>  CloudVersion(云版本信息)"
    
    def __unicode__(self):
        obj_name = self.cloud_obj.cloud_type + '/' + self.version_type
        return obj_name

    @property
    def project_count(self):
        project_count = ProjectInfo.objects.filter(project_version_obj__version_id=self.version_id).count()
        return project_count

    @property
    def host_count(self):
        host_count = HostNameInfo.objects.filter(host_project_obj__project_version_obj__version_id=self.version_id).count()
        return host_count

    @property
    def av_health_index_num(self):
        host_health_list =  [_.av_health_index_num for _ in  ProjectInfo.objects.filter(project_version_obj__version_id=self.version_id)] 
        try: 
            av_health_index_num = sum(host_health_list) / len(host_health_list)
        except Exception as e:
            av_health_index_num = 0
        return av_health_index_num

    @property
    def newest_check_health_num(self):
        host_health_list =  [_.newest_check_health_num for _ in  ProjectInfo.objects.filter(project_version_obj__version_id=self.version_id)] 
        try: 
            av_health_index_num = sum(host_health_list) / len(host_health_list)
        except Exception as e:
            av_health_index_num = 0
        return av_health_index_num

    """该版本中根据健康值划定范围 [0,60],(60,80],(80,100]"""
    @property
    def health_range_info(self):
        health_range_dict_list =  [_.health_range_info for _ in  ProjectInfo.objects.filter(project_version_obj__version_id=self.version_id)] 
        num_0_60_num = sum([_.get("0-60") for _ in health_range_dict_list])
        num_60_80_num = sum([_.get("60-80") for _ in health_range_dict_list])
        num_80_100_num = sum([_.get("80-100") for _ in health_range_dict_list])
        health_range_dict = {"0-60":num_0_60_num,"60-80":num_60_80_num,"80-100":num_80_100_num}
        return health_range_dict

    """版本的 每个项目中每台主机最新一次检查项的统计（统计check status is 1）"""
    """return :  [(u'kdump_conf', 119), (u'cat_proc_cmdline', 119), (u'dns_info', 117), (u'kdump_status', 108), (u'ip_route_show', 106)]  """
    @property
    def check_host_info_version_stat(self):
        project_stat_list = [ dict(_.check_host_info_project_stat) for _ in ProjectInfo.objects.filter(project_version_obj__version_id=self.version_id)]
        dict1 = {}

        for dict_obj in project_stat_list:
            dict1 = dict(Counter(dict1)+Counter(dict_obj))
        as_dict = sorted(dict1.iteritems(),key=lambda d:d[1],reverse=True) #字典排序
        return as_dict

class ProjectInfo(models.Model):
    project_id = models.AutoField("ID",primary_key=True,max_length=8)
    project_name = models.CharField("项目名称",blank=True, null=True, max_length=24)
    project_version_obj = models.ForeignKey(CloudVersion)
    project_start_date = models.CharField("项目开始时间",blank=True, null=True, max_length=24)
    project_description = models.CharField("项目描述",blank=True, null=True, max_length=1000)
    """异步更新字段"""
    """
        {
            "newest_health":80,
            "host_count_db":80,
            "check_item_stat":[["kdump_conf", 835], ["dns_info", 823], ["cat_proc_cmdline", 622], ["kdump_status", 477], ["ip_route_show", 351], ["dmesg", 105], ["fstab_info", 23], ["ifconfig", 21], ["docker_info", 18], ["bonding_info", 13], ["ipmitool_lan_print_1", 9], ["copy_system_files", 7], ["netstat_anpo", 5], ["ipmitool_sel_elist", 4], ["uptime", 1], ["df_h", 1]]
    """
    asy_json = models.TextField("异步入库数据",default="") 
    
    class Meta:
        db_table = "project_info"
        verbose_name_plural = "<3>  ProjectInfo(项目表)"

    def __unicode__(self):
        obj_name = self.project_version_obj.cloud_obj.cloud_type + "/" + self.project_version_obj.version_type + "/" + self.project_name
        return obj_name

    @property
    def host_count(self):
        return HostNameInfo.objects.filter(host_project_obj__project_id=self.project_id).count()

    @property
    def av_health_index_num(self):
        host_health_list =  [_.av_health_index_num for _ in  HostNameInfo.objects.filter(host_project_obj__project_id=self.project_id)] 
        try: 
            av_health_index_num = sum(host_health_list) / len(host_health_list)
        except Exception as e:
            av_health_index_num = 0
        return av_health_index_num

    @property
    def newest_check_health_num(self):
        newest_check_health_list = [_.newest_check_health_num for _ in  HostNameInfo.objects.filter(host_project_obj__project_id = self.project_id)]
        try:
            av_newest_health_index_num = sum(newest_check_health_list) / len(newest_check_health_list)
        except Exception as e:
            av_newest_health_index_num = 0
        return av_newest_health_index_num

    """该项目中根据健康值划定范围 [0,60],(60,80],(80,100]"""
    @property
    def health_range_info(self):
        newest_check_health_list = [_.newest_check_health_num for _ in  HostNameInfo.objects.filter(host_project_obj__project_id = self.project_id)]
        num_0_60_num = len([_ for _ in newest_check_health_list if 0 <= _ <= 60])
        num_60_80_num = len([_ for _ in newest_check_health_list if 60 < _ <= 80])
        num_80_100_num = len([_ for _ in newest_check_health_list if 80 < _ <= 100])
        health_range_dict = {"0-60":num_0_60_num,"60-80":num_60_80_num,"80-100":num_80_100_num}
        return health_range_dict
         
    """该项目的所有主机最新一次检查项目统计(check status is 1)eg:[(u'history', 2), (u'kdumps', 1)]"""
    """ check status 0 ok 1 fail 2 warning """
    @property
    def check_host_info_project_stat(self):
        check_host_info_list = [ host_obj.newest_check_host_info_dict  for host_obj in  HostNameInfo.objects.filter(host_project_obj__project_id=self.project_id) ]
        stat_info_dict = {}

        for _ in check_host_info_list:
            for key,value in _.items():
                if value == 1 and key not in stat_info_dict:
                #if  key not in stat_info_dict:
                    stat_info_dict[key] = 0
                if value == 1 and key  in stat_info_dict:
                    stat_info_dict[key] += 1
        as_dict = sorted(stat_info_dict.iteritems(),key=lambda d:d[1],reverse=True)
        return as_dict


class HostNameInfo(models.Model):
    host_id = models.AutoField("ID",primary_key=True, max_length=8)
    host_address = models.CharField("主机地址",blank=True, null=True, max_length=1000)
    host_project_obj = models.ForeignKey(ProjectInfo)
    host_description = models.CharField("描述",blank=True, null=True, max_length=1000)
    """异步更新字段"""
    newest_check_health_num_asy = models.IntegerField("最新健康指数",default=0) 
    newest_check_date_asy = models.CharField("最新监测日期",default=0, max_length=1000)
    oldest_check_date_asy = models.CharField("最早监测日期",default=0, max_length=1000)

    class Meta:
        db_table = "host_name_info"
        verbose_name_plural = "<4>  HostNameInfo(项目主机名表)"

    def __unicode__(self):
        obj_name = self.host_project_obj.project_version_obj.cloud_obj.cloud_type + "/" + self.host_project_obj.project_version_obj.version_type + "/" + self.host_project_obj.project_name + "/" + self.host_address
        return obj_name

    """ 每台主机对应存储的检查日期表 """
    @property
    def storage_check_date_table_name(self):
        hash_result = self.host_id % 10 
        return "HostCheckDateInfo_{hash_result}".format(hash_result=hash_result)

    @property
    def host_check_date_form(self):
        if self.newest_check_date_asy != 0:
            time_stamp = time.mktime(datetime.strptime(self.newest_check_date_asy, '%Y-%m-%d-%H-%M-%S').timetuple())
            return datetime.fromtimestamp(time_stamp).strftime("%Y-%m-%d %H:%M")
        return ''
    
    """ 每台主机对应存储的检查信息表 """
    @property
    def storage_check_info_table_name(self):
        hash_result = self.host_id % 10 
        return "HostCheckInfo_{hash_result}".format(hash_result=hash_result)

    """ 每台主机对应存储的主机信息表 """
    @property
    def storage_host_info_table_name(self):
        hash_result = self.host_id % 10 
        return "HostInfo_{hash_result}".format(hash_result=hash_result)

    # 稍后删除
    @property
    def storage_info_table_name(self):
        hash_result = self.host_id % 10
        return "HostInfo_{hash_result}".format(hash_result=hash_result)

    @property
    def av_health_index_num(self):
        host_checkdate_info_health_list = [_.health_index_num for _ in eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id)]
        try:
            av_health_index_num = sum(host_checkdate_info_health_list) / len(host_checkdate_info_health_list)
        except Exception as e:
            av_health_index_num = 0
        return av_health_index_num
    
    @property
    def check_host_count(self):
        check_count = eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id).count()
        return check_count

    @property
    def newest_check_health_num(self):
        newest_check_health_num = eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id).order_by("-host_check_date")[:1][0].health_index_num
        return newest_check_health_num

    @property
    def newest_check_date(self):
        newest_check_date = eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id).order_by("-host_check_date")[:1][0].host_check_date
        return newest_check_date

    @property
    def oldest_check_date(self):
        oldest_check_date = eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id).order_by("host_check_date")[:1][0].host_check_date
        return oldest_check_date
        
        

    """ 一台主机最新check的一次对应的check_info 相当于collection时候的json文件 eg:{"history":1},{"kdump":0} """
    @property
    def newest_check_host_info_dict(self):
        newest_check_date_id = eval(self.storage_check_date_table_name).objects.filter(host_name_obj__host_id=self.host_id).order_by("-host_check_date")[:1][0].host_check_date_id
        host_check_info_table_name = self.storage_check_info_table_name
        newest_check_host_info_id_list =  [ _.host_check_info_id for _ in eval(host_check_info_table_name).objects.filter(host_check_date_obj__host_check_date_id=newest_check_date_id)]
        check_host_info_dict = dict([ (i.name,i.status) for i in [ eval(host_check_info_table_name).objects.get(host_check_info_id=check_info_id) for check_info_id in newest_check_host_info_id_list ]])
        return check_host_info_dict

class HostCheckDateInfo(models.Model):
    host_check_date_id = models.AutoField("ID",primary_key=True, max_length=24)
    host_check_date = models.CharField("检测日期",max_length=800)
    host_name_obj = models.ForeignKey(HostNameInfo)
    check_report_link = models.CharField("检查报告连接",blank=True, null=True, max_length=800)
    collection_log_tarball_link = models.CharField("收集系统日志tarball下载链接",blank=True, null=True, max_length=800)
    health_index_num = models.IntegerField("健康指数",default=0) 
    description = models.CharField("描述",blank=True, null=True, max_length=1000)
    
    class Meta:
        abstract = True

    def __unicode__(self):
        #local_time_utc8 = localtime(self.host_check_date)
        #obj_name = self.host_name_obj.host_project_obj.project_version_obj.cloud_obj.cloud_type + "/" + self.host_name_obj.host_project_obj.project_version_obj.version_type + "/" + self.host_name_obj.host_project_obj.project_name + "/" + self.host_name_obj.host_address + "/" + local_time_utc8.strftime("%Y-%m-%d %H:%M:%S")
        #return obj_name
        obj_name = self.host_name_obj.host_project_obj.project_version_obj.cloud_obj.cloud_type + "/" + self.host_name_obj.host_project_obj.project_version_obj.version_type + "/" + self.host_name_obj.host_project_obj.project_name + "/" + self.host_name_obj.host_address + "/" + self.host_check_date
        return obj_name
    
    @property
    def host_check_date_time(self):
        if self.host_check_date:
            time_stamp = time.mktime(datetime.strptime(self.host_check_date, '%Y-%m-%d-%H-%M-%S').timetuple())
            return datetime.fromtimestamp(time_stamp).strftime("%Y-%m-%d %H:%M")
        return ''

class HostCheckDateInfo_0(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_0"
        verbose_name_plural = "<5.0> HostCheckDateInfo_0 (主机检测日期信息表0)"

class HostCheckDateInfo_1(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_1"
        verbose_name_plural = "<5.1> HostCheckDateInfo_1 (主机检测日期信息表1)"

class HostCheckDateInfo_2(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_2"
        verbose_name_plural = "<5.2> HostCheckDateInfo_2 (主机检测日期信息表2)"

class HostCheckDateInfo_3(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_3"
        verbose_name_plural = "<5.3> HostCheckDateInfo_3 (主机检测日期信息表3)"

class HostCheckDateInfo_4(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_4"
        verbose_name_plural = "<5.4> HostCheckDateInfo_4 (主机检测日期信息表4)"

class HostCheckDateInfo_5(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_5"
        verbose_name_plural = "<5.5> HostCheckDateInfo_5 (主机检测日期信息表5)"

class HostCheckDateInfo_6(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_6"
        verbose_name_plural = "<5.6> HostCheckDateInfo_6 (主机检测日期信息表6)"

class HostCheckDateInfo_7(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_7"
        verbose_name_plural = "<5.7> HostCheckDateInfo_7 (主机检测日期信息表7)"

class HostCheckDateInfo_8(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_8"
        verbose_name_plural = "<5.8> HostCheckDateInfo_8 (主机检测日期信息表8)"

class HostCheckDateInfo_9(HostCheckDateInfo):
    class Meta(HostCheckDateInfo.Meta):
        abstract = False
        db_table = "host_check_date_info_9"
        verbose_name_plural = "<5.9> HostCheckDateInfo_9 (主机检测日期信息表9)"

class HostInfo(models.Model):
    host_info_id = models.AutoField("ID",primary_key=True, max_length=24)
    server = models.CharField("服务器型号",blank=True, null=True, max_length=800)
    processors = models.CharField("处理器型号",blank=True, null=True, max_length=800)
    memory = models.CharField("内存型号",blank=True, null=True, max_length=800)
    disk_controller = models.CharField("磁盘控制器版本",blank=True, null=True, max_length=800)
    system_info = models.CharField("操作系统信息",blank=True, null=True, max_length=800)
    kernel_version = models.CharField("kernel版本",blank=True, null=True, max_length=800)
    bios_version = models.CharField("BIOS",blank=True, null=True, max_length=800)

    class Meta:
        abstract = True
    def __unicode__(self):
        return self.server            


class HostInfo_0(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_0)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_0"
        verbose_name_plural = "<6.0> HostInfo_0(主机信息表0)"

class HostInfo_1(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_1)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_1"
        verbose_name_plural = "<6.1> HostInfo_1(主机信息表1)"

class HostInfo_2(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_2)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_2"
        verbose_name_plural = "<6.2> HostInfo_2(主机信息表2)"

class HostInfo_3(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_3)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_3"
        verbose_name_plural = "<6.3> HostInfo_3(主机信息表3)"

class HostInfo_4(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_4)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_4"
        verbose_name_plural = "<6.4> HostInfo_4(主机信息表4)"

class HostInfo_5(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_5)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_5"
        verbose_name_plural = "<6.5> HostInfo_5(主机信息表5)"

class HostInfo_6(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_6)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_6"
        verbose_name_plural = "<6.6> HostInfo_6(主机信息表6)"

class HostInfo_7(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_7)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_7"
        verbose_name_plural = "<6.7> HostInfo_7(主机信息表7)"

class HostInfo_8(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_8)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_8"
        verbose_name_plural = "<6.8> HostInfo_8(主机信息表8)"

class HostInfo_9(HostInfo):
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_9)
    class Meta(HostInfo.Meta):
        abstract = False
        db_table = "host_info_9"
        verbose_name_plural = "<6.9> HostInfo_9(主机信息表9)"

class HostCheckInfo(models.Model):
    host_check_info_id = models.AutoField("ID",primary_key=True, max_length=24)
    name = models.CharField("检测项名称",blank=True, null=True, max_length=800)
    status = models.IntegerField("检查状态",default=0)
    reason = models.TextField("错误信息",blank=True, null=True)
    
    class Meta:
        abstract = True
    def __unicode__(self):
        return self.name


class HostCheckInfo_0(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_0)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_0"
        verbose_name_plural = "<7.0> HostCheckInfo_0(被检测主机分析信息表0)"

class HostCheckInfo_1(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_1)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_1"
        verbose_name_plural = "<7.1> HostCheckInfo_1(被检测主机分析信息表1)"

class HostCheckInfo_2(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_2)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_2"
        verbose_name_plural = "<7.2> HostCheckInfo_2(被检测主机分析信息表2)"

class HostCheckInfo_3(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_3)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_3"
        verbose_name_plural = "<7.3> HostCheckInfo_3(被检测主机分析信息表3)"

class HostCheckInfo_4(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_4)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_4"
        verbose_name_plural = "<7.4> HostCheckInfo_4(被检测主机分析信息表4)"

class HostCheckInfo_5(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_5)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_5"
        verbose_name_plural = "<7.5> HostCheckInfo_5(被检测主机分析信息表5)"

class HostCheckInfo_6(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_6)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_6"
        verbose_name_plural = "<7.6> HostCheckInfo_6(被检测主机分析信息表6)"

class HostCheckInfo_7(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_7)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_7"
        verbose_name_plural = "<7.7> HostCheckInfo_7(被检测主机分析信息表7)"

class HostCheckInfo_8(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_8)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_8"
        verbose_name_plural = "<7.8> HostCheckInfo_8(被检测主机分析信息表8)"

class HostCheckInfo_9(HostCheckInfo):
    host_name_obj = models.ForeignKey(HostNameInfo)
    host_check_date_obj = models.ForeignKey(HostCheckDateInfo_9)

    class Meta(HostCheckInfo.Meta):
        abstract = False
        db_table = "host_check_info_9"
        verbose_name_plural = "<7.9> HostCheckInfo_9(被检测主机分析信息表9)"

"""检查项 对应中文名称 模型"""
class CheckItemNameMap(models.Model):
    check_item_name_EN = models.CharField("检查项名称EN",blank=True, null=True,max_length=80)
    check_item_name_CN = models.CharField("检查项名称CN",blank=True, null=True,max_length=80)
    resolve_info =  models.TextField("故障解决方案",blank=True, null=True)

    class Meta:
        db_table = "check_item_name_map"
        verbose_name_plural = "<8> CheckItemNameMap(check item EN name map CN name)"

    def __unicode__(self):         
        return self.check_item_name_EN 

#""" 虚拟模型 场景：专有云对应所有主机 """
#class QueryHostView(models.Model):
#    host_id = models.AutoField("ID",primary_key=True, max_length=8)
#    host_address = models.CharField("主机地址",blank=True, null=True, max_length=1000)
#    host_project_obj = models.ForeignKey(ProjectInfo)
#    host_description = models.CharField("描述",blank=True, null=True, max_length=1000)
#    newest_check_health_num_asy = models.IntegerField("最新健康指数",default=0) 
#    newest_check_date_asy = models.CharField("最新监测日期",default=0, max_length=1000) 
#    
#    class Meta:
#        db_table = "query_host_view"
#        verbose_name_plural = "<9> query host view table"
#    @property
#    def host_check_date_form(self):
#        if self.newest_check_date_asy != 0:
#            time_stamp = time.mktime(datetime.strptime(self.newest_check_date_asy, '%Y-%m-%d-%H-%M-%S').timetuple())
#            return datetime.fromtimestamp(time_stamp).strftime("%Y-%m-%d %H:%M")
#        return ''
#
#""" 虚拟模型 场景：专有云-v2 对应所有主机 """
#class QueryV2HostView(models.Model):
#    host_id = models.AutoField("ID",primary_key=True, max_length=8)
#    host_address = models.CharField("主机地址",blank=True, null=True, max_length=1000)
#    host_project_obj = models.ForeignKey(ProjectInfo)
#    host_description = models.CharField("描述",blank=True, null=True, max_length=1000)
#    newest_check_health_num_asy = models.IntegerField("最新健康指数",default=0) 
#    newest_check_date_asy = models.CharField("最新监测日期",default=0, max_length=1000) 
#    
#    class Meta:
#        db_table = "query_v2_host_view"
#        verbose_name_plural = "<10> query host view table"
#    @property
#    def host_check_date_form(self):
#        if self.newest_check_date_asy != 0:
#            time_stamp = time.mktime(datetime.strptime(self.newest_check_date_asy, '%Y-%m-%d-%H-%M-%S').timetuple())
#            return datetime.fromtimestamp(time_stamp).strftime("%Y-%m-%d %H:%M")
#        return ''
#
#""" 虚拟模型 场景：专有云-v3 对应所有主机 """
#class QueryV3HostView(models.Model):
#    host_id = models.AutoField("ID",primary_key=True, max_length=8)
#    host_address = models.CharField("主机地址",blank=True, null=True, max_length=1000)
#    host_project_obj = models.ForeignKey(ProjectInfo)
#    host_description = models.CharField("描述",blank=True, null=True, max_length=1000)
#    newest_check_health_num_asy = models.IntegerField("最新健康指数",default=0) 
#    newest_check_date_asy = models.CharField("最新监测日期",default=0, max_length=1000) 
#    
#    class Meta:
#        db_table = "query_v3_host_view"
#        verbose_name_plural = "<10> query host view table"
#    @property
#    def host_check_date_form(self):
#        if self.newest_check_date_asy != 0:
#            time_stamp = time.mktime(datetime.strptime(self.newest_check_date_asy, '%Y-%m-%d-%H-%M-%S').timetuple())
#            return datetime.fromtimestamp(time_stamp).strftime("%Y-%m-%d %H:%M")
#        return ''
