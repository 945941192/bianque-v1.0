
#coding=utf-8

from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt

import os
import subprocess
import time
import base64
import json
import re
from os_web.settings import OSSBUCKET  
from os_web.settings import PROJEKT_DIR,FilePath
from aliyun.models import CloudType,CloudVersion,ProjectInfo,HostNameInfo,HostCheckDateInfo_0,HostCheckDateInfo_1,HostCheckDateInfo_2,HostCheckDateInfo_3,HostCheckDateInfo_4,HostCheckDateInfo_5,HostCheckDateInfo_6,HostCheckDateInfo_7,HostCheckDateInfo_8,HostCheckDateInfo_9,HostInfo_0,HostInfo_1,HostInfo_2,HostInfo_3,HostInfo_4,HostInfo_5,HostInfo_6,HostInfo_7,HostInfo_8,HostInfo_9,HostCheckInfo_0,HostCheckInfo_1,HostCheckInfo_2,HostCheckInfo_3,HostCheckInfo_4,HostCheckInfo_5,HostCheckInfo_6,HostCheckInfo_7,HostCheckInfo_8,HostCheckInfo_9,CheckItemNameMap
from tools.util import pull_gitlab,down_tarball_push_oss,check_item_name_map
from check.models import UploadTarBallInfo,ScriptToolsInfo
################################# select2 ajax #######################################
@csrf_exempt
def handle_project_list(request):
    #only cloud_version_id can find  cloud-version-project info
    #    cloud_type_id = request.GET.get('cloud_type_id')
    cloud_version_id = request.GET.get('cloud_version_id')
    key = request.GET.get('q')
    project_version_obj = CloudVersion.objects.get(version_id=int(cloud_version_id))
    #project_objs = ProjectInfo.objects.only("project_name").all()
    project_objs = ProjectInfo.objects.filter(project_version_obj=project_version_obj)
    if key:
        project_objs = project_objs.filter(project_name__contains=key)
    return JsonResponse({"results":[{"id":obj.project_id,"text":obj.project_name} for obj in project_objs]})


################################# select2 ajax end #######################################

@csrf_exempt
def handle_cloud_version(request):
    version_set = CloudVersion.objects.filter(cloud_obj__cloud_type="专有云")
    for _ in version_set:
        try:
            json_data = json.loads(_.asy_json)
            _.health_num = json_data.get("newest_health")
            _.host_count_db = json_data.get("host_count_db")
            _.project_count_db = json_data.get("project_count_db")
        except Exception as e:  #刚刚入库或者新创建项目  未奔跑定时任务
            _.health_num = "数据加载中"
            _.host_count_db = "数据加载中"
            _.project_count_db = "数据加载中"
    return render(request,"aliyun/cloud_version.html",{"version_set":version_set})


@csrf_exempt
def handle_version_project(request):
    version_id = request.GET.get('version_id')
    version = request.GET.get('version')
    project_set = ProjectInfo.objects.filter(project_version_obj__version_id=int(version_id))
    for _ in project_set:
        """当创建项目的时候，数据库没有json的情况"""
        try:
            json_data = json.loads(_.asy_json)
            _.health_num = json_data.get("newest_health")
            _.host_count_db = json_data.get("host_count_db")
        except Exception as e:
            _.health_num = 0
            _.host_count_db = "数据加载中"
    return render(request,"aliyun/version_project.html",{"project_sets":project_set,"type_info":version})

@csrf_exempt
def handle_project_host(request):
    version = request.GET.get('version')
    project_id = int(request.GET.get('project_id'))
    project_name = request.GET.get('project_name')
    project_host_set = HostNameInfo.objects.filter(host_project_obj__project_id=project_id)
    return render(request,"aliyun/project_host.html",{"project_host_set":project_host_set,"version":version,"project_name":project_name})

@csrf_exempt
def handle_host_check_date(request):
    version = request.GET.get('version')
    project_name = request.GET.get('project_name')
    host_name = request.GET.get('host_name')
    host_id = request.GET.get('host_id')
    #获取 一次检查主机对应的 主机信息表名称
    check_date_table_name = HostNameInfo.objects.get(host_id=host_id).storage_check_date_table_name
    check_date_host_table_name = "HostInfo_{}".format(check_date_table_name.split('_')[-1])
    host_check_date_set = eval(check_date_table_name).objects.filter(host_name_obj__host_id=host_id)
    for check_date_obj in host_check_date_set:
        try:
            query_host_info_obj = eval(check_date_host_table_name).objects.get(host_check_date_obj__host_check_date_id = check_date_obj.host_check_date_id)
        except Exception as e:
            query_host_info_obj = ''
        check_date_obj.host_info_obj = query_host_info_obj
    return render(request,"aliyun/host_check_date.html",{"host_check_date_set":host_check_date_set,"version":version,"project_name":project_name,"host_name":host_name,"host_id":host_id})

@csrf_exempt
def handle_host_analysis_info(request):
    version = request.GET.get('version')
    project_name = request.GET.get('project_name')
    host_name = request.GET.get('host_name')
    #根据主机id  和  check日期中对象id 确定 故障分析表中所要查询对象
    host_id = request.GET.get('host_id')
    check_date_id = request.GET.get('check_date_id')
    #根据 主机id 找到 check_date 表  ---》找到故障分析表
    check_date_table_name = HostNameInfo.objects.get(host_id=int(host_id)).storage_check_date_table_name
    host_check_info_table_name = "HostCheckInfo_{}".format(check_date_table_name.split('_')[-1])
    host_check_info_set = eval(host_check_info_table_name).objects.filter(host_name_obj__host_id=host_id,host_check_date_obj__host_check_date_id=check_date_id)
    for obj in host_check_info_set:
        if len(CheckItemNameMap.objects.filter(check_item_name_EN=obj.name)) == 0:
            obj.resolve_info = "暂无解决方案"
        else:
            obj.resolve_info = CheckItemNameMap.objects.get(check_item_name_EN=obj.name).resolve_info
        obj.name = check_item_name_map(obj.name)
    return render(request,"aliyun/check_host_info.html",{"host_check_info_set":host_check_info_set,"version":version,"project_name":project_name,"host_name":host_name,})

############################################## 查询 ###########################################################
@csrf_exempt
def handle_query_host(request):
    """ 
        专有云 查询页面 
    """
    cloud_type_set = CloudType.objects.all()
    version_set = CloudVersion.objects.filter(cloud_obj__cloud_type="专有云")
    check_item_set = CheckItemNameMap.objects.all()
    health_range = {
                        1:"0-60",
                        2:"60-80",
                        3:"80-100"
                    }

    response_data = {
                        "cloud_type_set" : cloud_type_set,
                        "version_set"    : version_set,
                        "check_item_set" : check_item_set,
                        "health_range"   : health_range,
                    }

    if request.method == "GET":

        return render(request,"aliyun/query_host.html",response_data)     

    elif request.method == "POST":

        #get option
        cloud_type = u"专有云"
        version_id = request.POST.get("cloud_version_id")
        project_id_list = [int(_) for _ in request.POST.getlist("project_id")]
        check_item_id = request.POST.get("check_item_id")
    #    health_range_id = request.POST.get("health_range_id")
        date_range = request.POST.get("date_range")
    #    print "*"*90,request.POST
    #    print cloud_type,version_id,project_id_list,check_item_id,health_range_id,date_range

        #get query set
        if cloud_type == u"专有云":
#            host_set = HostNameInfo.objects.filter(host_project_obj__project_version_obj__cloud_obj__cloud_type=cloud_type)
            host_set = QueryHostView.objects.all()
            
        if version_id != "all":
            version_type = CloudVersion.objects.get(version_id=int(version_id)).version_type
            print "version_type==",version_type
            if version_type == "v2":
                host_set = QueryV2HostView.objects.all()
            elif version_type == "v3":
            #    host_set = HostNameInfo.objects.filter(host_project_obj__project_version_obj__version_id=int(version_id))
                host_set = QueryV3HostView.objects.all()
        
        if len(project_id_list) != 0:
            host_set = HostNameInfo.objects.filter(host_project_obj__project_id__in=project_id_list)
           
      #  if health_range_id != "all":
      #      health_range_info = tuple([int(_) for _ in health_range.get(int(health_range_id)).split('-')])
      #      print "health_range_info===",health_range_info
            #host_set = HostNameInfo.objects.filter(host_project_obj__project_id__in=project_id_list)
            
#            host_set = HostNameInfo.objects.filter(host_project_obj__project_id__in=project_id_list)

#        host_set = HostNameInfo.objects.filter(host_project_obj__project_id__in=project_id_list)

        response_data["host_set"] = host_set
        #return HttpResponse("hello,world")
        return render(request,"aliyun/query_host.html",response_data)     
        


############################################## End 查询 #######################################################
############################################### 项目管理 #######################################################

@csrf_exempt
def handle_add_project(request):
    if request.method == "GET":
        cloud_type_set = CloudType.objects.all()
        version_set = CloudVersion.objects.all()
        response_data = {
                "cloud_type_set" : cloud_type_set,
                "version_set"    : version_set,
                        }
        return render(request,"aliyun/add_project.html",response_data)
    elif request.method == "POST":
        cloud_type_id = request.POST.get('cloud_type_id')
        cloud_version_id = int(request.POST.get("cloud_version_id"))
        project_name = request.POST.get("project_name")
        project_description = request.POST.get("project_instructions")
        project_start_date = request.POST.get("project_start_date")
        project_obj = ProjectInfo()
        project_obj.project_name = project_name
        project_obj.project_version_obj_id = cloud_version_id
        project_obj.project_description = project_description
        project_obj.project_start_date = project_start_date
        project_obj.save()
        return JsonResponse({"msg":"ok"})

@csrf_exempt
def handle_upload_host_check_log(request):
    if request.method == "GET":
        version_set = CloudVersion.objects.filter(cloud_obj__cloud_type="专有云")
        response_data = {
                "version_set"    : version_set,
                            }
        return render(request,"aliyun/upload_host_check_log.html",response_data)

    elif request.method == "POST":
### 获得前端传过来的云版本以及项目ID 起始
        cloud_version_id = request.POST.get('cloud_version_id','')
        if cloud_version_id:
            cloud_version_name = CloudVersion.objects.get(version_id=int(cloud_version_id)).version_type
        project_id = request.POST.get('project_id','')
        if project_id:
            project_name = ProjectInfo.objects.get(project_id=int(project_id)).project_name
### 获得前端传过来的云版本以及项目ID 结束
        tarball = request.FILES.get("host_check_log")
        remarks = request.POST.get("description")
        path_status = os.path.exists(FilePath)
        if not path_status:
            os.makedirs(FilePath)
        full_path_tarball = FilePath + tarball.name
#save /var/log
        with open(full_path_tarball,"w") as pic:
            for c in tarball.chunks():
                pic.write(c)
### 文件名中包含日期，截取其中的日期 起始
        try:
            host_check_date = tarball.name.split(r'.')[1]
        except Exception as e:
            host_check_date = ''
### 文件名中包含日期，截取其中的日期 结束
#check tar_ball
        pull_gitlab()
        cld_check_script_path = subprocess.check_output("find {PROJEKT_DIR} -name cld_check.sh".format(PROJEKT_DIR=PROJEKT_DIR),shell=True).strip()
        check_status = subprocess.call("sh {cld_check_script_path} -c -f  {full_path_tarball}".format(cld_check_script_path=cld_check_script_path,full_path_tarball=full_path_tarball),shell=True)
#tar -zxf tarball
        tar_x_tarball = subprocess.call("cd {FilePath} && tar -zxf {full_path_tarball}".format(FilePath=FilePath,full_path_tarball=full_path_tarball),shell=True)
#upload oss bucket  *.tar.gz  and check_report.html
        HOST = base64.b64decode(OSSBUCKET.get('HOST'))
        ID = base64.b64decode(OSSBUCKET.get('ID'))
        KEY = base64.b64decode(OSSBUCKET.get('KEY'))
        BUCKETNAME = OSSBUCKET.get('BUCKETNAME')
        try:
            upload_oss_back_info = subprocess.check_output("osscmd put {full_path_tarball} oss:{BUCKETNAME} --host {HOST} --id {ID} --key {KEY}".format(BUCKETNAME=BUCKETNAME,full_path_tarball=full_path_tarball,HOST=HOST,ID=ID,KEY=KEY),shell=True)
        except Exception as e:
            print e
            return HttpResponse("{tarball_name}上传oss失败".format(tarball_name=tarball.name))
        tarball_url = upload_oss_back_info.split("URL is: ")[1].split('\n')[0].replace("%2F","/")
        log_dir = full_path_tarball.replace(".tar.gz","")

        check_report_html_path = subprocess.check_output("find {log_dir} -name *.html".format(log_dir=log_dir),shell=True).strip()
        try:
            upload_check_report_html_oss_back_info = subprocess.check_output("osscmd put {check_report_html_path} oss:{BUCKETNAME} --host {HOST} --id {ID} --key {KEY}".format(BUCKETNAME=BUCKETNAME,check_report_html_path=check_report_html_path,HOST=HOST,ID=ID,KEY=KEY),shell=True)
        except Exception as e:
            tarball_base_path = full_path_tarball.replace(".tar.gz","")
#            subprocess.call("cd {FilePath} && rm -rf {tarball_base_path}".format(FilePath=FilePath,tarball_base_path=tarball_base_path+"*"),shell=True)
            return HttpResponse("检查 {tarball_name} 没有生成check report，请输入正确的tarball".format(tarball_name=tarball.name))
        check_report_url = upload_check_report_html_oss_back_info.split("URL is: ")[1].split('\n')[0].replace("%2F","/")
#rm local tarball*
        tarball_base_path = full_path_tarball.replace(".tar.gz","")
#        res = subprocess.call("cd {FilePath} && rm -rf {tarball_base_path}".format(FilePath=FilePath,tarball_base_path=tarball_base_path+"*"),shell=True)
#save
        tarball_obj = UploadTarBallInfo()
        tarball_obj.file_name = tarball.name
        tarball_obj.remarks = remarks
        tarball_obj.up_status = 1
        tarball_obj.tarball_url = tarball_url
        if check_status == 0:
            tarball_obj.check_status = 1
        tarball_obj.check_report_url = check_report_url
        tarball_obj.save()
### 多表插入数据 开始
        try:
#获取json文件路径 始
            host_name_info_json_file = subprocess.check_output("cd {log_dir} && find . -name '*.json' |grep {host_check_date} ".format(log_dir=log_dir,host_check_date=host_check_date),shell=True)
            if not host_name_info_json_file:
                return HttpResponse("没有产生json文件，请检查，谢谢！")
            host_name_info_json_file_name = host_name_info_json_file[2:].strip().strip('\n')
#获取json文件路径 束
        except Exception as e:
            print e
        path = log_dir+'/' + host_name_info_json_file_name
#解析json并获取hostname 始
        with open(path, 'r') as fr:
            host_name_info_json = json.load(fr,strict=False)
        host_name = host_name_info_json['HOSTINFO']['hostname']
#解析json并获取hostname 束
        host_obj_exist = HostNameInfo.objects.filter(host_address=host_name,host_project_obj__project_id=project_id)
#根据条件判断是否需要插入表host_name_info 始
        if not host_obj_exist:
            try:
                host_obj = HostNameInfo()
                host_obj.host_address=host_name
                host_project=ProjectInfo.objects.get(project_id=project_id)
                host_obj.host_project_obj=host_project
                host_obj.save()
            except Exception as e:
                print e
                return HttpResponse("保存主机信息失败，请检查，谢谢！")  
        host_obj = HostNameInfo.objects.get(host_address=host_name,host_project_obj__project_id=project_id)
#根据条件判断是否需要插入表host_name_info 束
#初始化三个模型类 比如：HostCheckDateInfo_9、HostCheckInfo_9、HostInfo_9 始
        HostCheckDateInfo = eval(host_obj.storage_check_date_table_name)()
        HostCheckInfo = eval(host_obj.storage_check_info_table_name)()
        HostInfo = eval(host_obj.storage_info_table_name)()
#初始化三个模型类 比如：HostCheckDateInfo_9、HostCheckInfo_9、HostInfo_9 束
#获取需要的字段值并插入到表HostCheckDateInfo_9 包括日期、健康度、查看url、外键对象  始
        date_obj_exist=eval(host_obj.storage_check_date_table_name).objects.filter(host_check_date=host_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
        if not date_obj_exist:
            try:
                HostCheckDateInfo.host_check_date = host_check_date
                HostCheckDateInfo.health_index_num = host_name_info_json['HOSTINFO']['os_health']
                HostCheckDateInfo.check_report_link = check_report_url
                HostCheckDateInfo.host_name_obj = host_obj
                HostCheckDateInfo.save()
            except Exception as e:
                print e
                return HttpResponse("保存日期信息失败，请检查，谢谢！")
        else:
            return HttpResponse("同一个项目同一台主机同一日期的包信息已存在，请勿重复上传，谢谢！")
#获取需要的字段值并插入到表HostCheckDateInfo_X 包括日期、健康度、查看url、外键对象  束
#获取需要的字段值并插入到表HostInfo_X 包括CPU、内存、OS等信息以及 外键对象  起
        hostinfo_obj_exist = eval(host_obj.storage_info_table_name).objects.filter(host_check_date_obj__host_check_date=host_check_date,host_check_date_obj__host_name_obj__host_address=host_name,host_check_date_obj__host_name_obj__host_project_obj__project_id=project_id)
        if not hostinfo_obj_exist:
            try:
                HostInfo.host_check_date_obj = HostCheckDateInfo
                HostInfo.server = host_name_info_json['HOSTINFO']['server_model']
                HostInfo.processors = host_name_info_json['HOSTINFO']['processor_model']
                HostInfo.memory = host_name_info_json['HOSTINFO']['memory_model']
                HostInfo.disk_controller = host_name_info_json['HOSTINFO']['dsk_crtl_modle']
                HostInfo.system_info = host_name_info_json['HOSTINFO']['os_release']
                HostInfo.kernel_version = host_name_info_json['HOSTINFO']['os_kernel']
                HostInfo.bios_version = host_name_info_json['HOSTINFO']['bios_type']
                HostInfo.save()
            except Exception as e:
                print e
                return HttpResponse("保存主机状态信息失败，请检查，谢谢！")
#获取需要的字段值并插入到表HostInfo_X 包括CPU、内存、OS等信息以及 外键对象  束
#获取需要的字段值并一次性插入多条记录到表HostCheckInfo_X 包括检测项名称、状态、错误信息 以及外键对象 起
        hostcheckinfo_obj_exist = eval(host_obj.storage_check_info_table_name).objects.filter(host_check_date_obj__host_check_date=host_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
        if not hostcheckinfo_obj_exist: 
            try:
                querysetlist=[]
                for each in host_name_info_json['CHECKINFO']:
                    querysetlist.append(eval(host_obj.storage_check_info_table_name)(status=each['status'],name=each['name'],reason=each['info'],host_name_obj = host_obj,host_check_date_obj = HostCheckDateInfo))
                eval(host_obj.storage_check_info_table_name).objects.bulk_create(querysetlist)
            except Exception as e:
                return HttpResponse("保存主机各项检测信息失败，请检查，谢谢！") 
#获取需要的字段值并一次性插入多条记录到表HostCheckInfo_X 包括检测项名称、状态、错误信息 以及外键对象 束
###多表插入数据 结束
###删除日志文件  起始
        subprocess.call("cd {FilePath} && rm -rf {tarball_base_path}".format(FilePath=FilePath,tarball_base_path=tarball_base_path+"*"),shell=True)
###删除日志文件  结束

        return HttpResponseRedirect(reverse("aliyun:upload_host_check_log"))

@csrf_exempt
def handle_upload_project_check_log(request):
    if request.method == "GET":
        version_set = CloudVersion.objects.filter(cloud_obj__cloud_type="专有云")
        response_data = {
                "version_set"    : version_set,
                            }
        return render(request,"aliyun/upload_project_check_log.html",response_data)
    elif request.method == "POST":
### 获得前端传过来的云版本以及项目ID 起始
        cloud_version_id = request.POST.get('cloud_version_id','')
        if cloud_version_id:
            cloud_version_name = CloudVersion.objects.get(version_id=int(cloud_version_id)).version_type
        project_id = request.POST.get('project_id','')
        if project_id:
            project_name = ProjectInfo.objects.get(project_id=int(project_id)).project_name
### 获得前端传过来的云版本以及项目ID 结束
### 获取前端上传的文件并保存 起始
        tarball = request.FILES.get("project_check_log")
        path_status = os.path.exists(FilePath)
        if not path_status:
            os.makedirs(FilePath)
        full_path_tarball = FilePath + tarball.name
        with open(full_path_tarball,"w") as pic:
            for c in tarball.chunks():
                pic.write(c)
### 获取前端上传的文件并保存 结束
### 获取oss文件上传权限 起始
        HOST = base64.b64decode(OSSBUCKET.get('HOST'))
        ID = base64.b64decode(OSSBUCKET.get('ID'))
        KEY = base64.b64decode(OSSBUCKET.get('KEY'))
        BUCKETNAME = OSSBUCKET.get('BUCKETNAME')
### 获取oss文件上传权限 结束
### 解压上传的项目包 起始
        subprocess.call("cd {FilePath} && tar -zxf {full_path_tarball}".format(FilePath=FilePath,full_path_tarball=full_path_tarball),shell=True)
        tar_x_tarball = subprocess.check_output("cd {FilePath} && tar ztf {full_path_tarball}".format(FilePath=FilePath,full_path_tarball=full_path_tarball),shell=True)
        current_tarball_path = tar_x_tarball.split('\n')[0]
        tar_path_tarball = os.path.join(FilePath,current_tarball_path)
### 解压上传的项目包 结束
### 文件名中包含日期，截取项目包其中的项目日期 起始
#        try:
#            project_check_date = re.search(r"\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}",tarball.name).group(0)
#        except Exception as e:
#            project_check_date = ''
### 文件名中包含日期，截取项目包其中的项目日期 结束
### 检查项目表是否有对应的记录 如果没有就先添加 起始
        project_obj_exist = ProjectInfo.objects.filter(project_id=project_id,project_version_obj__version_id=cloud_version_id)
        if not project_obj_exist:
            return HttpResponse("请先添加对应的项目，请检查，谢谢！")
### 检查项目表是否有对应的记录 如果没有就先添加 结束
### 如果项目表中存在对应的记录，就解析json和html文件并存入相关的表 起始
        else:
### 解析出成对的html和json文件并存入字典 起始
            try:
                project_dict = {}
                path_list = os.listdir(tar_path_tarball)
                for html_or_json in path_list:
                    is_file=os.path.join(tar_path_tarball,html_or_json)
                    if os.path.isdir(is_file):
                        continue
                    key = html_or_json.split('.')[0] 
                    html_json_flag = html_or_json.split('.')[-1]
                    if html_json_flag in ['html','json']:
                        if key in project_dict:
                            project_dict[key].append(is_file)
                        else:
                            project_dict[key] = [is_file]
            except Exception as e:
                print e
                return HttpResponse("项目包解析出现错误，请检查是否缺失json或html文件，谢谢！") 
### 解析出成对的html和json文件并存入字典 结束
            host_list = [] 
            for each_file_list in project_dict:
                sub_project_check_date = project_dict[each_file_list][0].split('.')[-2]
### 如果是html文件 获得其url 起始
                for one_file in project_dict[each_file_list]:
                    file_ext = os.path.splitext(one_file)[1]
                    if file_ext == '.html':
                        upload_project_html_oss_info = subprocess.check_output("osscmd put {check_report_html_path} oss:{BUCKETNAME} --host {HOST} --id {ID} --key {KEY}".format(BUCKETNAME=BUCKETNAME,check_report_html_path=one_file,HOST=HOST,ID=ID,KEY=KEY),shell=True) 
                        check_report_url = upload_project_html_oss_info.split("URL is: ")[1].split('\n')[0].replace("%2F","/")
### 如果是html文件 获得其url 结束
                    elif file_ext == '.json':
#解析json并获取hostname 始
                        with open(one_file, 'r') as fr:
                            host_name_info_json = json.load(fr,strict=False)
                        host_name = host_name_info_json['HOSTINFO']['hostname']
                        host_list.append(host_name)
                        host_health = host_name_info_json['HOSTINFO']['os_health']

#解析json并获取hostname 束
                        host_obj_exist = HostNameInfo.objects.filter(host_address=host_name,host_project_obj__project_id=project_id)
####################### 增加限制条件，健康度为零 不能入库
                        if  host_health:
#根据条件判断是否需要插入表host_name_info 始
                            if not host_obj_exist:
                                try:
                                    host_obj = HostNameInfo()
                                    host_obj.host_address=host_name
                                    host_project=ProjectInfo.objects.get(project_id=project_id)
                                    host_obj.host_project_obj=host_project
                                    host_obj.save()
                                except Exception as e:
                                    print e
                                    return HttpResponse("保存主机信息失败，请检查，谢谢！")
                            try:
                                host_obj = HostNameInfo.objects.get(host_address=host_name,host_project_obj__project_id=project_id)
#根据条件判断是否需要插入表host_name_info 束
#初始化三个模型类 比如：HostCheckDateInfo_9、HostCheckInfo_9、HostInfo_9 始
                                HostCheckDateInfo = eval(host_obj.storage_check_date_table_name)()
                                HostCheckInfo = eval(host_obj.storage_check_info_table_name)()
                                HostInfo = eval(host_obj.storage_info_table_name)()
#初始化三个模型类 比如：HostCheckDateInfo_9、HostCheckInfo_9、HostInfo_9 束
#获取需要的字段值并插入到表HostCheckDateInfo_9 包括日期、健康度、查看url、外键对象  始
                                date_obj_exist=eval(host_obj.storage_check_date_table_name).objects.filter(host_check_date=sub_project_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
                                if not date_obj_exist:
                                    try:
                                        HostCheckDateInfo.host_check_date = sub_project_check_date
                                        HostCheckDateInfo.health_index_num = host_health
                                        HostCheckDateInfo.check_report_link = check_report_url
                                        HostCheckDateInfo.host_name_obj = host_obj
                                        HostCheckDateInfo.save()
                                    except Exception as e:
                                        print e
                                        return HttpResponse("保存日期信息失败，请检查，谢谢！")
#获取需要的字段值并插入到表HostCheckDateInfo_X 包括日期、健康度、查看url、外键对象  束
#获取需要的字段值并插入到表HostInfo_X 包括CPU、内存、OS等信息以及 外键对象  起
                                hostinfo_obj_exist = eval(host_obj.storage_info_table_name).objects.filter(host_check_date_obj__host_check_date=sub_project_check_date,host_check_date_obj__host_name_obj__host_address=host_name,host_check_date_obj__host_name_obj__host_project_obj__project_id=project_id)
                                if not hostinfo_obj_exist:
                                    try:       
                                        HostCheckDateInfo_obj = eval(host_obj.storage_check_date_table_name).objects.get(host_check_date=sub_project_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
                                        HostInfo.host_check_date_obj = HostCheckDateInfo_obj
                                        HostInfo.server = host_name_info_json['HOSTINFO']['server_model']
                                        HostInfo.processors = host_name_info_json['HOSTINFO']['processor_model']
                                        HostInfo.memory = host_name_info_json['HOSTINFO']['memory_model']
                                        HostInfo.disk_controller = host_name_info_json['HOSTINFO']['dsk_crtl_modle']
                                        HostInfo.system_info = host_name_info_json['HOSTINFO']['os_release']
                                        HostInfo.kernel_version = host_name_info_json['HOSTINFO']['os_kernel']
                                        HostInfo.bios_version = host_name_info_json['HOSTINFO']['bios_type']
                                        HostInfo.save()
                                    except Exception as e:
                                        print e
                                        return HttpResponse("保存主机状态信息失败，请检查，谢谢！")
#获取需要的字段值并插入到表HostInfo_X 包括CPU、内存、OS等信息以及 外键对象  束
#获取需要的字段值并一次性插入多条记录到表HostCheckInfo_X 包括检测项名称、状态、错误信息 以及外键对象 起
                                hostcheckinfo_obj_exist = eval(host_obj.storage_check_info_table_name).objects.filter(host_check_date_obj__host_check_date=sub_project_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
                                if not hostcheckinfo_obj_exist:
                                    try:
                                        HostCheckDateInfo_obj = eval(host_obj.storage_check_date_table_name).objects.get(host_check_date=sub_project_check_date,host_name_obj__host_address=host_name,host_name_obj__host_project_obj__project_id=project_id)
                                        querysetlist=[]
                                        for each in host_name_info_json['CHECKINFO']:
                                            querysetlist.append(eval(host_obj.storage_check_info_table_name)(status=each['status'],name=each['name'],reason=each['info'],host_name_obj = host_obj,host_check_date_obj = HostCheckDateInfo_obj))
                                        eval(host_obj.storage_check_info_table_name).objects.bulk_create(querysetlist)
                                    except Exception as e:
                                        print e
                                        return HttpResponse("保存主机各项检测信息失败，请检查，谢谢！")
                            except Exception as e:
                                print e
#获取需要的字段值并一次性插入多条记录到表HostCheckInfo_X 包括检测项名称、状态、错误信息 以及外键对象 束
###多表插入数据 结束
###删除日志文件  起始
#        subprocess.call("cd {FilePath} && rm -rf {tarball_base_path}".format(FilePath=FilePath,tarball_base_path='*'+project_check_date+"*"),shell=True)
        subprocess.call("cd {FilePath} && rm -rf {tarball_base_path}".format(FilePath=FilePath,tarball_base_path='*'+current_tarball_path.strip('/')+"*"),shell=True)
###删除日志文件  结束

                                                    
### 如果是html文件 获得其url 结束
        print list(set(host_list))
        return HttpResponseRedirect(reverse("aliyun:upload_project_check_log"))
