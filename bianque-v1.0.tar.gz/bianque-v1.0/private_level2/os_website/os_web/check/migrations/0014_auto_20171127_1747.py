# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('check', '0013_auto_20171030_1428'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='scripttoolsinfo',
            options={'verbose_name_plural': 'ScriptToolsInfo(\u7cfb\u7edf\u5de5\u5177\u8bf4\u660e)'},
        ),
        migrations.AlterModelOptions(
            name='uploadtarballinfo',
            options={'verbose_name_plural': 'UploadTarBarllInfo(\u4e0a\u4f20tarball\u4fe1\u606f)'},
        ),
        migrations.AlterField(
            model_name='scripttoolsinfo',
            name='creat_time',
            field=models.DateTimeField(auto_now=True, verbose_name=b'\xe5\x88\x9b\xe5\xbb\xba\xe6\x97\xb6\xe9\x97\xb4'),
        ),
        migrations.AlterField(
            model_name='scripttoolsinfo',
            name='tool_instructions',
            field=models.TextField(default=b'', max_length=1000, verbose_name=b'\xe5\xb7\xa5\xe5\x85\xb7\xe4\xbd\xbf\xe7\x94\xa8\xe8\xaf\xb4\xe6\x98\x8e'),
        ),
        migrations.AlterField(
            model_name='scripttoolsinfo',
            name='tool_name',
            field=models.CharField(default=b'', max_length=1000, verbose_name=b'\xe5\xb7\xa5\xe5\x85\xb7\xe5\x90\x8d\xe7\xa7\xb0'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='check_report_url',
            field=models.CharField(default=b'', max_length=1000, verbose_name=b'\xe6\xa3\x80\xe6\x9f\xa5\xe6\x8a\xa5\xe5\x91\x8a\xe4\xb8\x8b\xe8\xbd\xbd\xe5\x9c\xb0\xe5\x9d\x80'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='check_status',
            field=models.IntegerField(default=0, verbose_name=b'\xe6\xa3\x80\xe6\x9f\xa5\xe7\x8a\xb6\xe6\x80\x81'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='file_name',
            field=models.CharField(default=b'', max_length=1000, verbose_name=b'\xe5\x8e\x8b\xe7\xbc\xa9\xe5\x8c\x85\xe6\x96\x87\xe4\xbb\xb6\xe5\x90\x8d'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='remarks',
            field=models.TextField(default=b'', max_length=1000, verbose_name=b'\xe5\xa4\x87\xe6\xb3\xa8'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='tarball_url',
            field=models.CharField(default=b'', max_length=1000, verbose_name=b'\xe5\x8e\x8b\xe7\xbc\xa9\xe5\x8c\x85\xe4\xb8\x8b\xe8\xbd\xbd\xe5\x9c\xb0\xe5\x9d\x80'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='up_status',
            field=models.IntegerField(default=0, verbose_name=b'\xe4\xb8\x8a\xe4\xbc\xa0\xe7\x8a\xb6\xe6\x80\x81'),
        ),
        migrations.AlterField(
            model_name='uploadtarballinfo',
            name='upload_time',
            field=models.DateTimeField(auto_now=True, verbose_name=b'\xe4\xb8\x8a\xe4\xbc\xa0\xe6\x97\xb6\xe9\x97\xb4'),
        ),
    ]
