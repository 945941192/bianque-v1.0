#coding=utf-8

from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt

import os
import subprocess
import time
import base64
import json

from os_web.settings import OSSBUCKET  
from os_web.settings import PROJEKT_DIR,FilePath
from aliyun.models import CloudType,CloudVersion,ProjectInfo,HostNameInfo,HostCheckDateInfo_0,HostCheckDateInfo_1,HostCheckDateInfo_2,HostCheckDateInfo_3,HostCheckDateInfo_4,HostCheckDateInfo_5,HostCheckDateInfo_6,HostCheckDateInfo_7,HostCheckDateInfo_8,HostCheckDateInfo_9,HostInfo_0,HostInfo_1,HostInfo_2,HostInfo_3,HostInfo_4,HostInfo_5,HostInfo_6,HostInfo_7,HostInfo_8,HostInfo_9,HostCheckInfo_0,HostCheckInfo_1,HostCheckInfo_2,HostCheckInfo_3,HostCheckInfo_4,HostCheckInfo_5,HostCheckInfo_6,HostCheckInfo_7,HostCheckInfo_8,HostCheckInfo_9
from tools.util import pull_gitlab,down_tarball_push_oss,check_item_name_map



@csrf_exempt
def handle_version_project(request):
    if request.method == "GET":
        cloud_type = request.GET.get("cloud_type")  #目前cloud type 为专有云
        """可下探柱状图"""
        data = list()
        series = list()
        version_set = CloudVersion.objects.filter(cloud_obj__cloud_type=cloud_type)
        for _ in version_set:
#            name =  _.cloud_obj.cloud_type
            data_dict = {"name":None,"y":None,"drilldown":None}
            series_dict = {"name":None,"id":None,"data":[]}
            data_dict["name"] = _.version_type
            #data_dict["y"] = _.newest_check_health_num
            data_dict["y"] = json.loads(_.asy_json).get("newest_health")
            data_dict["drilldown"] = _.version_type
            data.append(data_dict)
            series_dict["name"] = _.version_type
            series_dict["id"] = _.version_type
            project_set = ProjectInfo.objects.filter(project_version_obj__version_id=_.version_id)
            #series_dict["data"] = dict([(pro_obj.project_name,json.loads(pro_obj.asy_json).get("newest_health")) for pro_obj in project_set])
            try: #新建项目时 json反序列化会报错,因为没有跑定时任务 无数据
                dict1 =  dict([(pro_obj.project_name,json.loads(pro_obj.asy_json).get("newest_health")) for pro_obj in project_set])
            except Exception as e:
                dict1 = dict()
                for pro_obj in project_set:
                    try:
                        dict1[pro_obj.project_name] = json.loads(pro_obj.asy_json).get("newest_health")
                    except Exception as e:
                        dict1[pro_obj.project_name] = 0
            as_dict = sorted(dict1.iteritems(),key=lambda d:d[1],reverse=True) #字典排序
            series_dict["data"] = [list(i) for i in as_dict]
            series.append(series_dict)
        """可下探饼状图"""
        brandsData = []
        drilldownSeries = []
        for _ in version_set:
            name =  _.cloud_obj.cloud_type
            brand_dict = {"name":None,"y":None,"drilldown":None}
            drill_dict = {"name":None,"id":None,"data":[]}
            brand_dict["name"] = _.version_type
           #brand_dict["y"] = _.host_count
            brand_dict["y"] = json.loads(_.asy_json).get("host_count_db")
            brand_dict["drilldown"] = _.version_type
            brandsData.append(brand_dict)
            drill_dict["name"] = _.version_type
            drill_dict["id"] = _.version_type
            health_range_info_dict = json.loads(_.asy_json).get("health_range_info_db")
            try:
                drill_dict["data"] = [["0-60",health_range_info_dict.get("0-60")],["60-80",health_range_info_dict.get("60-80")],["80-100",health_range_info_dict.get("80-100")]]
            except Exception as e:
                drill_dict["data"] = [["0-60",0],["60-80",0],["80-100",0]]
            drilldownSeries.append(drill_dict)

        """专有云 检查项-统计柱状图"""
        check_sord_info = json.loads(CloudType.objects.get(cloud_type="专有云").asy_json).get("check_item_stat")
        check_sord_dict_CN = dict()
        for key,val in dict(check_sord_info).items():
            check_item_name_CN = check_item_name_map(key)
            check_sord_dict_CN[check_item_name_CN] = val
        check_sord_info_CN = sorted(check_sord_dict_CN.iteritems(),key=lambda d:d[1],reverse=True)
        return render(request,"report/version_project.html",{"data":json.dumps(data),"series":json.dumps(series),"brandsData":json.dumps(brandsData),"drilldownSeries":json.dumps(drilldownSeries),"check_sord_info":json.dumps(check_sord_info_CN)})


@csrf_exempt
def handle_check_items_stat(request):
    if request.method == "GET":
        version_tag = request.GET.get("version_tag")
        version_type = request.GET.get("version_type")
        version_id = request.GET.get("version_id")
        project_tag = request.GET.get("project_tag")
        project_id = request.GET.get("project_id")
        project_name = request.GET.get("project_name")
        if version_tag:
            try:
                version_sord_info = json.loads(CloudVersion.objects.get(version_id=int(version_id)).asy_json).get("check_item_stat")
                version_sord_dict_CN = dict()
                for key,val in dict(version_sord_info).items():
                    version_item_name_CN = check_item_name_map(key)
                    version_sord_dict_CN[version_item_name_CN] = val
                version_sord_info_CN = sorted(version_sord_dict_CN.iteritems(),key=lambda d:d[1],reverse=True) 
            except Exception as e:
                return HttpResponse("没有奔跑定时任务，最新数据没有入库")
            return render(request,"report/check_items_stat.html",{"check_sord_info":json.dumps(version_sord_info_CN),"version_type":version_type})
        elif project_tag:
            try:
                project_sord_info = json.loads(ProjectInfo.objects.get(project_id=int(project_id)).asy_json).get("check_item_stat")
                project_sord_dict_CN = dict()
                for key,val in dict(project_sord_info).items():
                    check_item_name_CN = check_item_name_map(key)
                    project_sord_dict_CN[check_item_name_CN] = val
                project_sord_info_CN = sorted(project_sord_dict_CN.iteritems(),key=lambda d:d[1],reverse=True) 
            except Exception as e:
                raise e
                return HttpResponse("没有奔跑定时任务，最新数据没有入库")
            return render(request,"report/check_items_stat.html",{"check_sord_info":json.dumps(project_sord_info_CN),"version_type":version_type,"project_name":project_name})
