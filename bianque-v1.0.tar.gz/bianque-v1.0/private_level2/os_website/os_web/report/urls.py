#!/usr/bin/env python
# coding=utf-8

from django.conf.urls import url

from . import views

''' 所有关于报表、图表的url '''
urlpatterns = [
    #所有版本及其项目健康值报告
    url(r'^version_project$', views.handle_version_project, name='version_project'),

    #所有版本及其项目健康值报告
    url(r'^check_items_stat$', views.handle_check_items_stat, name='check_items_stat'),
]
