#!/usr/bin/env python
# coding=utf-8
from __future__ import absolute_import
from celery import shared_task

import datetime
import json

from aliyun.models import CloudType,CloudVersion,ProjectInfo,HostNameInfo

@shared_task
def test_task():
    with open('/var/weizhanbiao/crontab_test.txt','a') as f:
        f.write('hello%s\n'%datetime.datetime.now().strftime('%Y-%m-%d-%H-%M'))



"""
        {
            "newest_health":80,
            "host_count":80,
            "check_item_stat":{"history":50,"netstat":800}
        }
"""
@shared_task
def asy_json():
    #asy cloudType model
    for _ in CloudType.objects.all():
        cloud_type_asy_json_data = {"check_item_stat":None,}
        cloud_type_asy_json_data["check_item_stat"] = _.cloud_host_info_version_stat
        _.asy_json = json.dumps(cloud_type_asy_json_data)
        _.save()
    #asy cloud_version model
    for _ in CloudVersion.objects.all():
        cloud_version_asy_json_data = {"newest_health":None,"host_count_db":None,"project_count_db":None,"check_item_stat":None,"health_range_info_db":None}
        cloud_version_asy_json_data["newest_health"] = _.newest_check_health_num
        cloud_version_asy_json_data["host_count_db"] = _.host_count
        cloud_version_asy_json_data["project_count_db"] = _.project_count
        cloud_version_asy_json_data["check_item_stat"] = _.check_host_info_version_stat
        cloud_version_asy_json_data["health_range_info_db"] = _.health_range_info 
        _.asy_json = json.dumps(cloud_version_asy_json_data)
        _.save()
    #asy ProjectInfo model
    for _ in ProjectInfo.objects.all():
        project_asy_json_data = {"newest_health":None,"host_count_db":None,"check_item_stat":None}
        project_asy_json_data["newest_health"] = _.newest_check_health_num
        project_asy_json_data["host_count_db"] = _.host_count
        project_asy_json_data["check_item_stat"] = _.check_host_info_project_stat
        _.asy_json = json.dumps(project_asy_json_data)
        _.save()
    print "asy end cloud version"

"""
    定时填充 host_name_info 表：最新健康值/最新检查时间/最早检查时间
"""
@shared_task
def asy_update_host_name_model():
    for _ in HostNameInfo.objects.all():
        _.newest_check_health_num_asy = _.newest_check_health_num
        _.newest_check_date_asy = _.newest_check_date
        _.oldest_check_date_asy = _.oldest_check_date
        _.save()
