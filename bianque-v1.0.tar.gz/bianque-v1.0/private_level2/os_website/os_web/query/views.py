
#coding=utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from django.core.urlresolvers import reverse
from django.views.decorators.csrf import csrf_exempt

import os
import subprocess
import time
import base64
import json
import re
from os_web.settings import OSSBUCKET  
from os_web.settings import PROJEKT_DIR,FilePath
from aliyun.models import *
from .models import *

from tools.util import pull_gitlab,down_tarball_push_oss,check_item_name_map



@csrf_exempt
def handle_query_host(request):
    """ 
        专有云 查询页面 
    """
    cloud_type_set = CloudType.objects.all()
    version_set = CloudVersion.objects.filter(cloud_obj__cloud_type="专有云")
    check_item_set = CheckItemNameMap.objects.all()
    health_range = {
                        1:"0-60",
                        2:"60-80",
                        3:"80-100"
                    }

    response_data = {
                        "cloud_type_set" : cloud_type_set,
                        "version_set"    : version_set,
                        "check_item_set" : check_item_set,
                        "health_range"   : health_range,
                    }

    if request.method == "GET":
#        print "*"*90,request.GET,"hello"
        # get option   a is all
        cloud_id = CloudType.objects.get(cloud_type='专有云').cloud_id
        version_id = request.GET.get("cloud_version_id") if request.GET.get("cloud_version_id") else "a" 
        project_backups = request.GET.get("project_backups") if request.GET.get("project_backups") else "None"#项目选项第二次query时使用
#        print "project_backups=",project_backups,type(project_backups)
        project_id = request.GET.get("project_id") if request.GET.get("project_id") and request.GET.get("project_id") != "None" else project_backups
        check_item_id = request.GET.get("check_item_id") if request.GET.get("check_item_id") else "a"
        date_range = request.GET.get("date_range") if request.GET.get("date_range") else "All ..."
#        print "#"*10,project_id,type(project_id)
        project_name = ProjectInfo.objects.get(project_id = project_id).project_name if project_id  and project_id != "None" else "All ..."
#        print cloud_id,version_id,project_id,check_item_id,date_range,project_name

        response_data["version_id"] = version_id
        response_data["project_id"] = project_id
        response_data["project_name"] = project_name
        response_data["check_item_id"] = check_item_id
        response_data["date_range"] = date_range
        return render(request,"query/query_host.html",response_data)     

    elif request.method == "POST":
#        print request.POST
        #POST DATA
        start = int(request.POST.get("start",0))
        length = int(request.POST.get("length","10"))
        end = start + length
        search = request.POST.get("search[value]")
        draw = request.POST.get("draw")
#        print "start=%s,length=%s,search=%s,draw=%s"%(start,length,search,draw)

        #GET DATA
        version_id = request.GET.get("version_id")
        project_id = request.GET.get("project_id") if request.GET.get("project_id") != "None" else "a"
        check_item_id = request.GET.get("check_item_id")
        date_range = request.GET.get("date_range") if request.GET.get("date_range") != "All ..." else "a"
        print version_id,project_id,check_item_id,date_range

        """ Assemble response_json """
        response_json = {
                            "draw":None,
                            "recordsTotal":None,
                            "recordsFiltered":None,
                            "data":None,  #[{},{},{}]
                        }
        if check_item_id != "a":
            check_item_name = CheckItemNameMap.objects.get(id=check_item_id).check_item_name_EN
            item_query_host_table_name = "QueryHost_{check_item_name}".format(check_item_name=check_item_name)
            query_set = eval(item_query_host_table_name).objects.all()

            if version_id != "a":
                query_set = query_set.filter(version_id = version_id)

            if project_id != "a":
                query_set = query_set.filter(project_id = project_id)

            if date_range != "a":
                start_date = date_range.split(" - ")[0]
                end_date = date_range.split(" - ")[1]
                query_set = query_set.filter(newest_check_date__lte=end_date).filter(oldest_check_date__gte=start_date)

#            if check_item_id != "a":
            query_set = query_set.filter(check_item_id = check_item_id)

            host_set =  HostNameInfo.objects.filter(host_id__in=[_.host_id for _ in query_set[start:end]]).order_by("-newest_check_health_num_asy")

        elif check_item_id == "a":
            query_set = HostNameInfo.objects.all().order_by("-newest_check_health_num_asy")

            if version_id != "a":
                query_set = query_set.filter(host_project_obj__project_version_obj__version_id = version_id)

            if project_id != "a":
                query_set = query_set.filter(host_project_obj__project_id = project_id)

            if date_range != "a":
                start_date = date_range.split(" - ")[0]
                end_date = date_range.split(" - ")[1]
                query_set = query_set.filter(newest_check_date_asy__lte=end_date).filter(oldest_check_date_asy__gte=start_date)

            host_set = query_set[start:end]

        response_json["draw"] = draw
        response_json["recordsTotal"] = query_set.count()
        response_json["recordsFiltered"] = query_set.count()
        for host_obj in host_set:

            """ 主机名称跳转链接 """
            host_full_name = host_obj.__str__()
            version = host_full_name.split("/")[1]
            project_name = host_full_name.split("/")[2]
            url = reverse('aliyun:host') + "?host_name={host_name}&&host_id={host_id}&&project_name={project_name}&&version={version}".format(host_name = host_obj.host_address,host_id = host_obj.host_id,project_name=project_name,version=version)
            host_obj.host_name_url = "<a href=\"{url}\"   target=\"_blank\">{host_name}</a>".format(url=url,host_name=host_obj.__str__())


            """ 健康值显示 """
            if host_obj.newest_check_health_num_asy >= 80:
                host_obj.health_show = "<div class=\"progress progress-striped\" style=\"margin-bottom: 0px;\"><div class=\"progress-bar progress-bar-success\" role=\"progressbar\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: {health_num}%;\"><span>{health_num_two}</span></div></div>".format(health_num=host_obj.newest_check_health_num_asy,health_num_two = host_obj.newest_check_health_num_asy)

            elif host_obj.newest_check_health_num_asy < 80 and host_obj.newest_check_health_num_asy >= 60:
                host_obj.health_show = "<div class=\"progress progress-striped\" style=\"margin-bottom: 0px;\"><div class=\"progress-bar progress-bar-warning\" role=\"progressbar\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: {health_num}%;\"><span>{health_num_two}</span></div></div>".format(health_num=host_obj.newest_check_health_num_asy,health_num_two = host_obj.newest_check_health_num_asy)
            
            elif host_obj.newest_check_health_num_asy < 60:
                host_obj.health_show = "<div class=\"progress progress-striped\" style=\"margin-bottom: 0px;\"><div class=\"progress-bar progress-bar-danger\" role=\"progressbar\" aria-valuenow=\"60\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: {health_num}%;\"><span>{health_num_two}</span></div></div>".format(health_num=host_obj.newest_check_health_num_asy,health_num_two = host_obj.newest_check_health_num_asy)


#        response_json["data"] = [{"host_name":_.__str__(),"newest_check_date":_.newest_check_date_asy,"newest_health_num":_.newest_check_health_num_asy} for _ in host_set]
        response_json["data"] = [{"host_name":_.host_name_url,"newest_check_date":_.newest_check_date_asy,"newest_health_num":_.health_show} for _ in host_set]
        
        return JsonResponse(response_json)

        
        

#        return JsonResponse({"draw":int(draw),"recordsTotal":57,"recordsFiltered":57,"data":[{"first_name":"Gavin","last_name":"Cortez","position":"Team Leader"}]})


        


