#coding=utf-8
from django.db import models

"""
扁鹊查询{根据 <云> <版本> <项目> <检查项> 查询主机}页面模型类
每个检查项对应一个查询模型
入库原则：利用脚本或者定时任务填充数据

"""

class QueryHostBase(models.Model):

    check_item_id = models.IntegerField("检测项ID") 
    cloud_id = models.IntegerField("云ID") 
    version_id = models.IntegerField("版本ID") 
    project_id = models.IntegerField("项目ID") 
    host_id = models.IntegerField("主机ID") 
    """warning: this date is 这台主机在该检测项发生错误时被统计，取出的max and min"""
    newest_check_date = models.CharField("最新检测日期",max_length=800)
    oldest_check_date = models.CharField("最早检测日期",max_length=800)
    
    class Meta:
        abstract = True

    def __unicode__(self):
        return "QueryHost"

"""QueryHost_<check-item> eg:QueryHost_history"""

class QueryHost_cmdline(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_cmdline"
        verbose_name_plural = "<11> QueryHost_cmdline (cmdline-查询主机)"

    def __unicode__(self):
        return "QueryHost_cmdline"

class QueryHost_df(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_df"
        verbose_name_plural = "<1> QueryHost_df (df-查询主机)"

    def __unicode__(self):
        return "QueryHost_df"

class QueryHost_free(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_free"
      verbose_name_plural = "<2> QueryHost_cmdline (free-查询主机)"

  def __unicode__(self):
      return "QueryHost_free"

class QueryHost_ps(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_ps"
      verbose_name_plural = "<3> QueryHost_ps (ps-查询主机)"

  def __unicode__(self):
      return "QueryHost_ps"

class QueryHost_ntp(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_ntp"
      verbose_name_plural = "<4> QueryHost_ntp (ntp-查询主机)"

  def __unicode__(self):
      return "QueryHost_ntp"

class QueryHost_dmesg(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_dmesg"
      verbose_name_plural = "<5> QueryHost_dmesg (dmesg-查询主机)"

  def __unicode__(self):
      return "QueryHost_dmesg"

class QueryHost_history(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_history"
      verbose_name_plural = "<6> QueryHost_history (history-查询主机)"

  def __unicode__(self):
      return "QueryHost_history"

class QueryHost_uptime(QueryHostBase):
  class Meta(QueryHostBase.Meta):
      abstract = False
      db_table = "query_host_uptime"
      verbose_name_plural = "<7> QueryHost_uptime (uptime-查询主机)"

  def __unicode__(self):
      return "QueryHost_uptime"

class QueryHost_fstab(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_fstab"
        verbose_name_plural = "<8> QueryHost_fstab (fstab-查询主机)"

    def __unicode__(self):
        return "QueryHost_fstab"

class QueryHost_kdump(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_kdump"
        verbose_name_plural = "<9> QueryHost_kdump (kdump-查询主机)"

    def __unicode__(self):
        return "QueryHost_kdump"

class QueryHost_kdump_conf(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_kdump_conf"
        verbose_name_plural = "<10> QueryHost_kdump_conf (kdump_conf-查询主机)"

    def __unicode__(self):
        return "QueryHost_kdump_conf"

class QueryHost_dns(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_dns"
        verbose_name_plural = "<12> QueryHost_dns (dns-查询主机)"

    def __unicode__(self):
        return "QueryHost_dns"

class QueryHost_iostat(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_iostat"
        verbose_name_plural = "<13> QueryHost_iostat (iostat-查询主机)"

    def __unicode__(self):
        return "QueryHost_iostat"

class QueryHost_lsof(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_lsof"
        verbose_name_plural = "<14> QueryHost_lsof (lsof-查询主机)"

    def __unicode__(self):
        return "QueryHost_lsof"

class QueryHost_cp_system_files(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_cp_system_files"
        verbose_name_plural = "<15> QueryHost_cp_system_files (cp_system_files-查询主机)"

    def __unicode__(self):
        return "QueryHost_cp_system_files"

class QueryHost_rpmdb_verify(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_rpmdb_verify"
        verbose_name_plural = "<16> QueryHost_rpmdb_verify (rpmdb_verify-查询主机)"

    def __unicode__(self):
        return "QueryHost_rpmdb_verify"

class QueryHost_iproute(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_iproute"
        verbose_name_plural = "<17> QueryHost_iproute (iproute-查询主机)"

    def __unicode__(self):
        return "QueryHost_iproute"

class QueryHost_ifconfig(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ifconfig"
        verbose_name_plural = "<18> QueryHost_ifconfig (ifconfig-查询主机)"

    def __unicode__(self):
        return "QueryHost_ifconfig"

class QueryHost_netstat(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_netstat"
        verbose_name_plural = "<19> QueryHost_netstat (netstat-查询主机)"

    def __unicode__(self):
        return "QueryHost_netstat"

class QueryHost_netstat_pro(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_netstat_pro"
        verbose_name_plural = "<20> QueryHost_netstat_pro (netstat_pro-查询主机)"

    def __unicode__(self):
        return "QueryHost_netstat_pro"

class QueryHost_netstat_dev(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_netstat_dev"
        verbose_name_plural = "<22> QueryHost_netstat_dev (netstat_dev-查询主机)"

    def __unicode__(self):
        return "QueryHost_netstat_dev"

class QueryHost_bonding_info(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_bonding_info"
        verbose_name_plural = "<23> QueryHost_bonding_info (bonding_info-查询主机)"

    def __unicode__(self):
        return "QueryHost_bonding_info"

class QueryHost_netcard_info(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_netcard_info"
        verbose_name_plural = "<24> QueryHost_netcard_info (netcard_info-查询主机)"

    def __unicode__(self):
        return "QueryHost_netcard_info"

class QueryHost_ipmifru(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ipmifru"
        verbose_name_plural = "<25> QueryHost_ipmifru (ipmifru-查询主机)"

    def __unicode__(self):
        return "QueryHost_ipmifru"

class QueryHost_ipmilan(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ipmilan"
        verbose_name_plural = "<26> QueryHost_ipmilan (ipmilan-查询主机)"

    def __unicode__(self):
        return "QueryHost_ipmilan"

class QueryHost_ipmisensor(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ipmisensor"
        verbose_name_plural = "<27> QueryHost_ipmisensor (ipmisensor-查询主机)"

    def __unicode__(self):
        return "QueryHost_ipmisensor"

class QueryHost_ipmisdr(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ipmisdr"
        verbose_name_plural = "<28> QueryHost_ipmisdr (ipmisdr-查询主机)"

    def __unicode__(self):
        return "QueryHost_ipmisdr"

class QueryHost_ipmisel(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_ipmisel"
        verbose_name_plural = "<29> QueryHost_ipmisel (ipmisel-查询主机)"

    def __unicode__(self):
        return "QueryHost_ipmisel"

class QueryHost_docker_info(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_docker_info"
        verbose_name_plural = "<30> QueryHost_docker_info (docker_info-查询主机)"

    def __unicode__(self):
        return "QueryHost_docker_info"

class QueryHost_raid_info(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_raid_info"
        verbose_name_plural = "<31> QueryHost_raid_info (raid_inifo-查询主机)"

    def __unicode__(self):
        return "QueryHost_raid_info"

class QueryHost_check_syslog(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_check_syslog"
        verbose_name_plural = "<32> QueryHost_check_syslog (check_syslog-查询主机)"

    def __unicode__(self):
        return "QueryHost_check_syslog"

class QueryHost_check_hardware(QueryHostBase):
    class Meta(QueryHostBase.Meta):
        abstract = False
        db_table = "query_host_check_hardware"
        verbose_name_plural = "<33> QueryHost_check_hardware (check_hardware-查询主机)"

    def __unicode__(self):
        return "QueryHost_check_hardware"
