#!/usr/bin/env python
# coding=utf-8

from django.conf.urls import url

from . import views

"""
    query app

"""
urlpatterns = [
    #查询主机页面接口
    url(r'^host$', views.handle_query_host, name='query_host'),
]
