#!/usr/bin/env python
# coding=utf-8
from __future__ import absolute_import
from celery import shared_task

import datetime
import json

from aliyun.models import *
from query.models import *


"""
    定时填充 host_name_info 表：最新健康值/最新存储时间/  
"""
@shared_task
def asy_update_host_name_model():
    for _ in HostNameInfo.objects.all():
        _.newest_check_health_num_asy = _.newest_check_health_num
        _.newest_check_date_asy = _.newest_check_date
        _.save()

"""
       定时更新查询主机数据模型

"""
@shared_task
def update_query_host_tables():

    check_item_dict = dict((_.check_item_name_EN,_.id)for _ in CheckItemNameMap.objects.all())

    for host_obj in HostNameInfo.objects.all():
        """获取 检查日期表/主机信息表/检查日期表 表名"""
        check_date_table_name = host_obj.storage_check_date_table_name
        host_info_table_name = host_obj.storage_host_info_table_name
        check_info_table_name = host_obj.storage_check_info_table_name

        # arg
        host_id = host_obj.host_id
        print "hostid=%d"%host_id
        project_id = host_obj.host_project_obj.project_id
        version_id = host_obj.host_project_obj.project_version_obj.version_id
        cloud_id = host_obj.host_project_obj.project_version_obj.cloud_obj.cloud_id
        check_item_id = None
        newest_date = None
        oldest_date = None 

        """ 循环填充检查项查询数据模型 """
        #if not host_id creat  if have update
        for item_name,check_item_id in check_item_dict.items(): 
            item_query_host_table_name = "QueryHost_{item_name}".format(item_name=item_name)
            try:
                exists_tag = eval(item_query_host_table_name).objects.filter(host_id = host_id).exists()
            except Exception as e:
                continue
            if not exists_tag:
                check_item_id = check_item_id

#            if not QueryHost_cmdline.objects.filter(host_id = host_id).exists():

#                check_item_id = check_item_dict.get("cmdline")

#            date_dict = dict([(_.host_check_date,_.host_check_date_id) for _ in eval(check_date_table_name).objects.filter(host_name_obj__host_id = host_id)])
                date_list = list()
                for check_date_obj in eval(check_date_table_name).objects.filter(host_name_obj__host_id = host_id):
                    #出现报错 因为有的主机检查项肯能为30项，所以get找不到
#                    if eval(check_info_table_name).objects.get(host_check_date_obj__host_check_date_id = check_date_obj.host_check_date_id,name=item_name).status == 1:
                    try:
                        if eval(check_info_table_name).objects.get(host_check_date_obj__host_check_date_id = check_date_obj.host_check_date_id,name=item_name).status == 1:
                            date_list.append(check_date_obj.host_check_date)
                    except Exception as e:
                        date_list = []
                if date_list:        
                    newest_date = max(date_list) 
                    oldest_date = min(date_list)
#            print "max:%s,min%s"%(newest_date,oldest_date)

                    query_host = eval(item_query_host_table_name)()
                    query_host.cloud_id = cloud_id
                    query_host.version_id = version_id
                    query_host.project_id = project_id
                    query_host.host_id = host_id 
                    query_host.check_item_id = check_item_id
                    query_host.newest_check_date = newest_date
                    query_host.oldest_check_date = oldest_date
                    query_host.save()
                    print "{table_name}-----------save-ok".format(table_name=item_query_host_table_name)
#                    print "save %s ok"%host_id
                else:
                    continue
#        print "{table_name}-----------save-ok".format(table_name=item_query_host_table_name)


    print "end"

