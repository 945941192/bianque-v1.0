# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('query', '0006_queryhost_cp_system_files_queryhost_iostat_queryhost_iproute_queryhost_lsof_queryhost_rpmdb_verify'),
    ]

    operations = [
        migrations.CreateModel(
            name='QueryHost_ifconfig',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ifconfig',
                'verbose_name_plural': '<18> QueryHost_ifconfig (ifconfig-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_netstat',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_netstat',
                'verbose_name_plural': '<19> QueryHost_netstat (netstat-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_netstat_pro',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_netstat_pro',
                'verbose_name_plural': '<20> QueryHost_netstat_pro (netstat_pro-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
    ]
