# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('query', '0007_queryhost_ifconfig_queryhost_netstat_queryhost_netstat_pro'),
    ]

    operations = [
        migrations.CreateModel(
            name='QueryHost_bonding_info',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_bonding_info',
                'verbose_name_plural': '<23> QueryHost_bonding_info (bonding_info-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_check_hardware',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_check_hardware',
                'verbose_name_plural': '<33> QueryHost_check_hardware (check_hardware-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_check_syslog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_check_syslog',
                'verbose_name_plural': '<32> QueryHost_check_syslog (check_syslog-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_docker_info',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_docker_info',
                'verbose_name_plural': '<30> QueryHost_docker_info (docker_info-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_ipmifru',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ipmifru',
                'verbose_name_plural': '<25> QueryHost_ipmifru (ipmifru-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_ipmilan',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ipmilan',
                'verbose_name_plural': '<26> QueryHost_ipmilan (ipmilan-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_ipmisdr',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ipmisdr',
                'verbose_name_plural': '<28> QueryHost_ipmisdr (ipmisdr-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_ipmisel',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ipmisel',
                'verbose_name_plural': '<29> QueryHost_ipmisel (ipmisel-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_ipmisensor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_ipmisensor',
                'verbose_name_plural': '<27> QueryHost_ipmisensor (ipmisensor-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_netcard_info',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_netcard_info',
                'verbose_name_plural': '<24> QueryHost_netcard_info (netcard_info-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_netstat_dev',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_netstat_dev',
                'verbose_name_plural': '<22> QueryHost_netstat_dev (netstat_dev-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_raid_info',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_raid_info',
                'verbose_name_plural': '<31> QueryHost_raid_info (raid_inifo-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
    ]
