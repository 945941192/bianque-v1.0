# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('query', '0001_initial'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='queryhost_cmdline',
            options={'verbose_name_plural': '<11> QueryHost_cmdline (cmdline-\u67e5\u8be2\u4e3b\u673a)'},
        ),
    ]
