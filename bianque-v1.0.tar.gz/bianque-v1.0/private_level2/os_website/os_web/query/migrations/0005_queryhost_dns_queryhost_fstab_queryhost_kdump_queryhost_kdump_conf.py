# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('query', '0004_queryhost_dmesg_queryhost_free_queryhost_history_queryhost_ntp_queryhost_ps_queryhost_uptime'),
    ]

    operations = [
        migrations.CreateModel(
            name='QueryHost_dns',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_dns',
                'verbose_name_plural': '<12> QueryHost_dns (dns-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_fstab',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_fstab',
                'verbose_name_plural': '<8> QueryHost_fstab (fstab-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_kdump',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_kdump',
                'verbose_name_plural': '<9> QueryHost_kdump (kdump-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
        migrations.CreateModel(
            name='QueryHost_kdump_conf',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('check_item_id', models.IntegerField(verbose_name=b'\xe6\xa3\x80\xe6\xb5\x8b\xe9\xa1\xb9ID')),
                ('cloud_id', models.IntegerField(verbose_name=b'\xe4\xba\x91ID')),
                ('version_id', models.IntegerField(verbose_name=b'\xe7\x89\x88\xe6\x9c\xacID')),
                ('project_id', models.IntegerField(verbose_name=b'\xe9\xa1\xb9\xe7\x9b\xaeID')),
                ('host_id', models.IntegerField(verbose_name=b'\xe4\xb8\xbb\xe6\x9c\xbaID')),
                ('newest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x96\xb0\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
                ('oldest_check_date', models.CharField(max_length=800, verbose_name=b'\xe6\x9c\x80\xe6\x97\xa9\xe6\xa3\x80\xe6\xb5\x8b\xe6\x97\xa5\xe6\x9c\x9f')),
            ],
            options={
                'abstract': False,
                'db_table': 'query_host_kdump_conf',
                'verbose_name_plural': '<10> QueryHost_kdump_conf (kdump_conf-\u67e5\u8be2\u4e3b\u673a)',
            },
        ),
    ]
